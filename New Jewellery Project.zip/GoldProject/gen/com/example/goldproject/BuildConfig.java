/** Automatically generated file. DO NOT MODIFY */
package com.example.goldproject;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}