package com.example.goldproject.fragments;

import android.content.Context;
import android.widget.ArrayAdapter;

public class GoldItemsPriceRangesAdapter extends ArrayAdapter{

	public GoldItemsPriceRangesAdapter (Context context, int textViewResourceId, String[] objects){

		super(context, textViewResourceId, objects);
	}

}
