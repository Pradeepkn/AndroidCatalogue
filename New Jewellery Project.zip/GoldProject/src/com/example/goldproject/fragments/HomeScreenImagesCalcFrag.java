package com.example.goldproject.fragments;

import com.example.goldproject.PositiveActivity;
import com.example.goldproject.R;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class HomeScreenImagesCalcFrag extends Fragment implements OnClickListener {

	private Activity calcActivity;

	private Dialog cDialog;

	private String finalGoldPrice;

	TextView priceEditText;

	EditText weightEditText;

	TextView wastageEditText;

	TextView makingEditText;

	TextView discountEditText;

	TextView vatEditText;
	
	@Override
	public void onAttach(Activity activity) {

		calcActivity = activity;

		super.onAttach(activity);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		System.out.println("homescreen images calculator fragment on create() started.......................");
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.homescreen_calc_frag, container, false);

		initSignUpComponenets(view);

		return view;
	}

	private void initSignUpComponenets(View view) {

		priceEditText = (TextView) view.findViewById(R.id.todaysPrice);

		weightEditText = (EditText) view.findViewById(R.id.WeightInGrams);

		wastageEditText = (TextView) view.findViewById(R.id.WastageCharges);

		makingEditText = (TextView) view.findViewById(R.id.MakingCharges);

		discountEditText = (TextView) view.findViewById(R.id.Discount);

		vatEditText = (TextView) view.findViewById(R.id.VAT);

		/*if ( Double.parseDouble(goldPrice) == 1000.00) {

			Double totalGoldPrice =  Double.parseDouble(goldPrice);

			finalGoldPrice = totalGoldPrice + "/-";

		}*/ /*else {*/

		Button calculateButton = (Button) view.findViewById(R.id.CalculateId);

		//add calculate button listener
		calculateButton.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {

		case R.id.CalculateId:

			//String goldPrice = priceEditText.getText().toString();

			String weightInGrams = weightEditText.getText().toString();

			//String wastageCharges = wastageEditText.getText().toString();

			//String makingCharges = makingEditText.getText().toString();

			//String discount = discountEditText.getText().toString();

			//String vat = vatEditText.getText().toString();

			Double actualPrice =  1000.00 * Double.parseDouble(weightInGrams); 

			Double totalGoldPrice = (((actualPrice/1.6) + (actualPrice/0.5)) - 0.3) + 0.5;

			String totalGoldPrice1 = totalGoldPrice.toString();

			finalGoldPrice = totalGoldPrice1 + "/-";
			//}

			System.out.println("finalGoldPrice----"+ finalGoldPrice);

			openAlert();

			break;

		case R.id.okText:

			Intent positveActivity = new Intent(getActivity().getApplicationContext(), PositiveActivity.class);

			startActivity(positveActivity);

		default:
			break;
		}
	}

	protected void openAlert() {

		cDialog = new Dialog(calcActivity, android.R.style.Theme_Translucent);

		cDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

		cDialog.setCancelable(true);

		cDialog.setContentView(R.layout.dialog);

		TextView finalGoldPriceView = (TextView) cDialog.findViewById(R.id.finalPriceCalc);

		finalGoldPriceView.setText(finalGoldPrice);

		TextView okTextView = (TextView) cDialog.findViewById(R.id.okText);

		okTextView.setOnClickListener(this);

		cDialog.show();
	}
}
