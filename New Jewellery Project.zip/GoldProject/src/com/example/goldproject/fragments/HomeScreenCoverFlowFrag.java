package com.example.goldproject.fragments;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.goldproject.HomeScreenImagesAdapter;
import com.example.goldproject.R;

import android.app.Activity;
import android.app.ProgressDialog;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import at.technikum.mti.fancycoverflow.FancyCoverFlow;

public class HomeScreenCoverFlowFrag extends Fragment {

	private JSONObject jObj;

	private String uri;

	//ImageView imageView;

	private FancyCoverFlow fancyCoverFlow;

	private HomeScreenImagesAdapter mAdapter;

	private Activity coverFlowActivity;

	@Override
	public void onAttach(Activity activity) {

		coverFlowActivity = activity;

		super.onAttach(activity);
	}

	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		System.out.println("coverflow homescreen images onCreate()......");
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.homescreen_coverflow_frag, container, false);

		initLoginComponents(view);

		return view;
	}

	private void initLoginComponents(View view) {

		this.fancyCoverFlow = (FancyCoverFlow) view.findViewById(R.id.fancyCoverFlow);
	}

	@SuppressWarnings("deprecation")
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {

		super.onActivityCreated(savedInstanceState);

		mAdapter = new HomeScreenImagesAdapter();

		//creation of fancy cover flow.

		this.fancyCoverFlow.setAdapter(mAdapter);

		this.fancyCoverFlow.setUnselectedAlpha(.3f);

		this.fancyCoverFlow.setUnselectedSaturation(0.0f);

		this.fancyCoverFlow.setUnselectedScale(0.4f);
		
		fancyCoverFlow.setReflectionEnabled(true);

		fancyCoverFlow.setReflectionRatio(0.25f);

		fancyCoverFlow.setReflectionGap(0);

		this.fancyCoverFlow.setSpacing(-150);

		this.fancyCoverFlow.setMaxRotation(60);

		this.fancyCoverFlow.setScaleDownGravity(0.1f);

		this.fancyCoverFlow.setActionDistance(FancyCoverFlow.ACTION_DISTANCE_AUTO);

		//homeList = new ArrayList<HomeScreen>();
		new JSONAsyncTask().execute("http://brinvents.com/jewellery/api/ListOfProducts/retrive.json?type=homeScreens");
	}
	private class JSONAsyncTask extends AsyncTask<String, Void, ArrayList<String>> {

		ProgressDialog dialog;

		@Override
		protected void onPreExecute() {

			super.onPreExecute();

			dialog = new ProgressDialog(coverFlowActivity);

			dialog.setMessage("LoadingImages, please Wait...");

			dialog.setTitle("connecting server..");

			dialog.show();

			dialog.setCancelable(false);
		}

		@Override
		protected ArrayList<String> doInBackground(String... urls) {

			try {
				HttpGet httpGet = new HttpGet(urls[0]);

				HttpClient httpclient = new DefaultHttpClient();

				HttpResponse response = httpclient.execute(httpGet);

				// StatusLine stat = response.getStatusLine();
				int status = response.getStatusLine().getStatusCode();

				if (status == 200) {

					HttpEntity entity = response.getEntity();

					String data = EntityUtils.toString(entity);

					JSONObject jsono = new JSONObject(data);

					System.out.println("response from the server-----------"+jsono);

					// Retrieve JSON Objects from the given website URL in JSONfunctions
					JSONObject result = jsono.getJSONObject("Result");

					// Retrieve JSON Objects
					// Storing each json item in variable
					int errorCode = result.getInt("errorCode");

					System.out.println("ERROR_CODE->"+errorCode);

					String errorMessage = result.getString("errorMessage");

					System.out.println("ERROR_MESSAGE->"+errorMessage);

					int statusCode = result.getInt("statusCode");

					System.out.println("STATUS_CODE->"+statusCode);

					// Locate the array name
					JSONArray jarray = result.getJSONArray("listOfItems");

					ArrayList<String> urlValues = new ArrayList<String>();

					for (int i = 0; i < jarray.length(); i++) 
					{
						jObj = jarray.getJSONObject(i);
						//imageView.setImageResource(R.drawable.ic_launcher);
						uri = jObj.getString("uri");

						System.out.println("uri----"+uri);

						urlValues.add(uri);
						//downloadImage(uri, "sample.png");
					}
					//new DownloadImageTask1(imageView).execute(uri);
					//new myAsyncTask().execute(uri);

					//getImageFromURL(uri);
					return urlValues;
				}
			} catch (ParseException e1) {

				e1.printStackTrace();

			} catch (IOException e) {

				e.printStackTrace();

			} catch (JSONException e) {

				e.printStackTrace();
			}
			return null;
		}

		protected void onPostExecute(ArrayList<String> urls) {

			dialog.cancel();
			//adapter.notifyDataSetChanged();
			/*if(result == false)
				Toast.makeText(mHomeScreen, "Unable to fetch data from server", Toast.LENGTH_LONG).show();*/
			if(urls != null) {

				mAdapter.setItems(urls);
			}
		}
	}
}
