package com.example.goldproject;

import java.util.ArrayList;

import com.example.goldproject.jewellerymodels.GoldItems;

import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.os.Bundle;

public class GoldFullScreenImage extends ActionBarActivity {

	private GoldFullScreenImageAdapter adapter;

	private ViewPager viewPager;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		getSupportActionBar().hide();

		setContentView(R.layout.activity_gold_full_screen_image);

		viewPager = (ViewPager) findViewById(R.id.goldSinglePager1);

		// Get intent data
		Intent i = getIntent();

		// Selected image id
		String position = i.getStringExtra("goldimgposition");

		// the value of an item that previously added with putExtra() or null if no Serializable value was found.
		ArrayList<GoldItems> items = (ArrayList<GoldItems>) i.getSerializableExtra("golditems");

		System.out.println("Position>>>" + position);

		adapter = new GoldFullScreenImageAdapter(GoldFullScreenImage.this, position);

		adapter.setItem(items);

		viewPager.setAdapter(adapter);
	}
}
