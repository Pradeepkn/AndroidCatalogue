package com.example.goldproject;

import java.util.ArrayList;

import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.os.Bundle;

public class GoldFullScreenImage extends ActionBarActivity {

	private GoldFullScreenImageAdapter adapter;

	private ViewPager viewPager;

	//	private Activity fActivity;

	//private Utils utils;

	/*@Override
	public void onAttach(Activity activity) {

		super.onAttach(activity);

		fActivity = activity;
	}*/

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		getSupportActionBar().hide();

		setContentView(R.layout.activity_gold_full_screen_image);

		viewPager = (ViewPager) findViewById(R.id.goldSinglePager1);

		//utils = new Utils(getApplicationContext());

		// Get intent data
		//		Intent i = getIntent();

		// Selected image id
		//		String position = i.getStringExtra("position");

		Bundle b = getIntent().getExtras();

		if(b!= null){

			ArrayList<String> fullImageList;

			fullImageList = (ArrayList<String>)b.getStringArrayList("position");

			System.out.println("Position>>>" + fullImageList);

			//fullImageList.add(position);

			adapter = new GoldFullScreenImageAdapter(GoldFullScreenImage.this, fullImageList);

			//adapter = new GoldFullScreenImageAdapter(GoldFullScreenImage.this, utils.getFilePaths());

			viewPager.setAdapter(adapter);
		}
	}
}

//		ArrayList<String> imgFileNameList = new ArrayList<String>();
//
//		imgFileNameList.add(position);

//		System.out.println("imgFileNameList--"+imgFileNameList);
//		
//		System.out.println("imgFileNameList size--"+imgFileNameList.size());

/*adapter = new GoldFullScreenImageAdapter(GoldFullScreenImage.this, position);

			//adapter = new GoldFullScreenImageAdapter(GoldFullScreenImage.this, utils.getFilePaths());
			viewPager.setAdapter(adapter);*/
//}

/*goldFullImageFlipper = (ViewFlipper) findViewById(R.id.goldFullScreenFlipper);

		ImageView fullImage = (ImageView) findViewById(R.id.goldFullImageView1);

		fullImage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				goldFullImageFlipper.setInAnimation(inFromLeftAnimation());

				goldFullImageFlipper.showNext();
			}
		});*/

// displaying selected image first
//		viewPager.setCurrentItem(position);

/*@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.fullscreen_image_viewflipper, container);

		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {

		super.onActivityCreated(savedInstanceState);

		viewPager = (ViewPager) getActivity().findViewById(R.id.goldSinglePager1);

		//utils = new Utils(getApplicationContext());

		// Get intent data
		Intent i = getActivity().getIntent();

		// Selected image id
		String position = i.getStringExtra("position");

		ArrayList<String> imgFileNameList = new ArrayList<String>();

		imgFileNameList.add(position);

		Log.d("Position>>>", "Position" + position);

		adapter = new GoldFullScreenImageAdapter(fActivity, imgFileNameList);

		viewPager.setAdapter(adapter);

		goldFullImageFlipper = (ViewFlipper) getActivity().findViewById(R.id.goldFullScreenFlipper);

		ImageView fullImage = (ImageView) getActivity().findViewById(R.id.goldFullImageView2);

		fullImage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				goldFullImageFlipper.setInAnimation(inFromLeftAnimation());

				goldFullImageFlipper.showPrevious();
			}
		});
	}*/
