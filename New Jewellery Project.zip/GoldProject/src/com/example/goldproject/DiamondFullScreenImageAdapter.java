package com.example.goldproject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import com.example.goldproject.jewellerymodels.DiamondItems;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class DiamondFullScreenImageAdapter extends PagerAdapter {

	private Activity gActivity;

	private ArrayList<DiamondItems> fullImageList = new ArrayList<DiamondItems>();

	private LayoutInflater layoutInflater;

	int Resource;

	int gPosition;

	//constructor
	public DiamondFullScreenImageAdapter(Activity activity){

		System.out.println("entering fullscreenimage adapter");

		this.gActivity = activity;

		//this.fullImageList = objectList;
		//this.fullImageList = objectList;
	}

	@Override
	public int getCount() {

		return this.fullImageList.size();
	}

	@Override
	public boolean isViewFromObject(View view, Object object) {

		return view == ((RelativeLayout)object);
	}

	@Override
	public Object instantiateItem(ViewGroup container, int position) {

		final DiamondItems items = fullImageList.get(position);

		ImageView imageDisplay;

		layoutInflater = (LayoutInflater) gActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		View viewLayout = layoutInflater.inflate(R.layout.diamondfullscreenimage, null);

		imageDisplay = (ImageView) viewLayout.findViewById(R.id.diamondGridimgDisplay);

		imageDisplay.setImageResource(R.drawable.ic_launcher);

		System.out.println("position----"+position);

		updateImageView(imageDisplay, "diamondfullfileName_" + position, items.url);

		/*BitmapFactory.Options options = new BitmapFactory.Options();

		options.inPreferredConfig = Bitmap.Config.ARGB_8888;

		Bitmap bitmap = BitmapFactory.decodeFile(fullImageList.get(position).getUri(), options);

		imageDisplay.setImageBitmap(bitmap);*/

		//((ViewPager) container).addView(viewLayout);

		return viewLayout;
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {

		((ViewPager) container).removeView((RelativeLayout) object);
	}

	private void updateImageView(ImageView bmImage, String filename, String url) {

		File SDCardRoot = Environment.getExternalStorageDirectory().getAbsoluteFile();
		//create a new file, specifying the path, and the filename
		//which we want to save the file as.
		//      String filename="downloadedFile.png";  
		File file = new File(SDCardRoot,filename);

		if(file.exists()) {

			BitmapFactory.Options options = new BitmapFactory.Options();

			options.inSampleSize = 8;

			Bitmap myBitmap = BitmapFactory.decodeFile(file.getAbsolutePath());

			bmImage.setImageBitmap(myBitmap);

		} else {

			new DownloadDiamondImageTask1(bmImage, filename).execute(url);
		}
	}

	public class DownloadDiamondImageTask1 extends AsyncTask<String, Void, Bitmap> {

		ImageView bmImage;

		private String mFileName;

		public DownloadDiamondImageTask1(ImageView bmImage, String filename) {

			this.bmImage = bmImage;

			this.mFileName = filename;
		}

		@Override
		protected Bitmap doInBackground(String... urls) {

			String urldisplay = urls[0];

			Bitmap bitmap = null;

			try {
				//set the download URL, a url that points to a file on the internet
				//this is the file to be downloaded
				URL url = new URL(urls[0]);

				System.out.println("url..."+url);
				//create the new connection
				HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

				//set up some things on the connection
				urlConnection.setRequestMethod("GET");

				urlConnection.setDoOutput(true);

				//and connect!
				urlConnection.connect();

				//set the path where we want to save the file
				//in this case, going to save it on the root directory of the
				//sd card.
				//return the path to the root of the external storage(SDcard).
				File SDCardRoot = Environment.getExternalStorageDirectory().getAbsoluteFile();
				//create a new file, specifying the path, and the filename
				//which we want to save the file as.
				//              String filename="downloadedFile.png";  
				File file = new File(SDCardRoot,mFileName);

				if(file.createNewFile())
				{
					file.createNewFile();
				}
				SDCardRoot.mkdir();
				//this will be used to write the downloaded data into the file we created
				FileOutputStream fileOutput = new FileOutputStream(file);

				//this will be used in reading the data from the internet
				InputStream inputStream = urlConnection.getInputStream();

				//this is the total size of the file
				int totalSize = urlConnection.getContentLength();

				System.out.println("total size......"+totalSize);
				//variable to store total downloaded bytes
				int downloadedSize = 0;

				//create a buffer...
				byte[] buffer = new byte[1024];

				int bufferLength = 0; //used to store a temporary size of the buffer

				//now, read through the input buffer and write the contents to the file
				while ((bufferLength = inputStream.read(buffer)) > 0 ) {
					//add the data in the buffer to the file in the file output stream (the file on the sd card)
					fileOutput.write(buffer, 0, bufferLength);
					//add up the size so we know how much is downloaded
					downloadedSize += bufferLength;
					//                    Log.i("Progress:","downloadedSize:"+downloadedSize+"totalSize:"+ totalSize) ;
					//this is where you would do something to report the progress, like this maybe
					//updateProgress(downloadedSize, totalSize);
				}
				//close the output stream when done
				fileOutput.close();

				InputStream in = new java.net.URL(urldisplay).openStream();

				bitmap = BitmapFactory.decodeStream(in);
				//catch some possible errors...
			} catch (MalformedURLException e) {

				e.printStackTrace();

			} catch (IOException e) {

				e.printStackTrace();
			}
			return bitmap;
		}
		// Sets the Bitmap returned by doInBackground
		@Override
		protected void onPostExecute(Bitmap result) {

			bmImage.setImageBitmap(result);
		}
	}
}
