package com.example.goldproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;

import com.example.goldproject.R;
import com.example.goldproject.fragments.PlatinumFullScreenImageAdapter;

public class PlatinumFullScreenImage extends ActionBarActivity {

	private PlatinumFullScreenImageAdapter dAdapter;

	private ViewPager viewPager;

	//private ArrayList<DiamondItems> fullImageList = new ArrayList<DiamondItems>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_platinum_full_screen_image);

		viewPager = (ViewPager) findViewById(R.id.platinumSinglePager1);

		// Get intent data
		Intent i = getIntent();

		// Selected image id
		int position = i.getExtras().getInt("position");

		Log.d("Position>>>", "Position" + position);

		dAdapter = new PlatinumFullScreenImageAdapter(this);

		viewPager.setAdapter(dAdapter);

		// displaying selected image first
		viewPager.setCurrentItem(position);
	}
}

