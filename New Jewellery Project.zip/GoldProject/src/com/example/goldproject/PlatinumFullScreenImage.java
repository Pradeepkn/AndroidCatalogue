package com.example.goldproject;

import java.util.ArrayList;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import com.example.goldproject.R;
import com.example.goldproject.jewellerymodels.PlatinumItems;

public class PlatinumFullScreenImage extends ActionBarActivity {

	private PlatinumFullScreenImageAdapter dAdapter;

	private ViewPager viewPager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		
		getSupportActionBar().hide();

		setContentView(R.layout.activity_platinum_full_screen_image);

		viewPager = (ViewPager) findViewById(R.id.platinumSinglePager1);

		// Get intent data
		Intent i = getIntent();

		// Selected image id
		String position = i.getStringExtra("platinumimgposition");
		
		ArrayList<PlatinumItems> items = (ArrayList<PlatinumItems>) i.getSerializableExtra("platinumitems");

		System.out.println("Position>>>" +position);

		dAdapter = new PlatinumFullScreenImageAdapter(PlatinumFullScreenImage.this, position);
		
		dAdapter.setItem(items);

		viewPager.setAdapter(dAdapter);

		// displaying selected image first
		//viewPager.setCurrentItem(position);
	}
}
