package com.example.goldproject;

import java.util.ArrayList;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import com.example.goldproject.R;
import com.example.goldproject.jewellerymodels.SilverItems;

public class SilverFullScreenImage extends ActionBarActivity {

	private SilverFullScreenImageAdapter sAdapter;

	private ViewPager viewPager;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		
		getSupportActionBar().hide();

		setContentView(R.layout.activity_silver_full_screen_image);

		viewPager = (ViewPager) findViewById(R.id.silverSinglePager1);

		// Get intent data
		Intent i = getIntent();

		// Selected image id
		String position = i.getStringExtra("silverimgposition");
		
		ArrayList<SilverItems> items = (ArrayList<SilverItems>) i.getSerializableExtra("silveritems");

		System.out.println("Position>>>" + position);
		
		sAdapter = new SilverFullScreenImageAdapter(SilverFullScreenImage.this, position);

		sAdapter.setItems(items);
		
		viewPager.setAdapter(sAdapter);

		// displaying selected image first
		//viewPager.setCurrentItem(position);
	}

	/*@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.gold_full_screen_image, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}*/

}
