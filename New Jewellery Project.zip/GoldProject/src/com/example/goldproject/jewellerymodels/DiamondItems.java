package com.example.goldproject.jewellerymodels;

public class DiamondItems {
	public String name;
	public String jewelleryType;
	public String gender;
	public String style;
	public String designType;
	public String clarity;
	public String color;
	public String size;
	public String url;
	public String price;
}
