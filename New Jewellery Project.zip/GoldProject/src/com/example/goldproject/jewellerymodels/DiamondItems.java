package com.example.goldproject.jewellerymodels;

import java.io.Serializable;

public class DiamondItems implements Serializable {
	
	private static final long serialVersionUID = 1L;
	public String name;
	public String jewelleryType;
	public String gender;
	public String style;
	public String designType;
	public String clarity;
	public String color;
	public String size;
	public String url;
	public String price;
}
