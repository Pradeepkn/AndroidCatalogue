package com.example.goldproject.jewellerymodels;

import java.util.ArrayList;

public class GoldProducts {
	
	public String productName;

	public ArrayList<GoldItems> items;
}
