package com.example.goldproject;

public class GoldList {

}
