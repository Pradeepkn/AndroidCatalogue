package com.example.goldproject;

import java.util.ArrayList;

import com.example.goldproject.jewellerymodels.DiamondItems;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.os.Bundle;

public class DiamondFullScreenImage extends ActionBarActivity {

	private DiamondFullScreenImageAdapter dAdapter;

	private ViewPager viewPager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		getSupportActionBar().hide();

		setContentView(R.layout.activity_diamond_full_screen_image);

		viewPager = (ViewPager) findViewById(R.id.diamondSinglePager1);

		// Get intent data
		Intent i = getIntent();

		// Selected image id
		String position = i.getStringExtra("diamondImgPostion");

		ArrayList<DiamondItems> items=(ArrayList<DiamondItems>) i.getSerializableExtra("diamonditems");

		System.out.println("Position>>>" + position);

		dAdapter = new DiamondFullScreenImageAdapter(DiamondFullScreenImage.this, position);

		dAdapter.setItem(items);

		viewPager.setAdapter(dAdapter);
	}
}
