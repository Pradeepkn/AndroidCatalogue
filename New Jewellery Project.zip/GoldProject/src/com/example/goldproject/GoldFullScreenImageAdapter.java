package com.example.goldproject;

import java.io.File;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class GoldFullScreenImageAdapter extends PagerAdapter {

	private Activity gActivity;

	private String filename;

	private ImageView imageDisplay;

	//private TextView goldItemsView;

	//	private ImageFetcher imageFetcher;

	private ArrayList<String> fullImageListUrl = new ArrayList<String>();

	private LayoutInflater layoutInflater;

	//constructor
	public GoldFullScreenImageAdapter(Activity activity, ArrayList<String> imgList) {

		System.out.println("entering Goldfullscreenimage adapter");

		this.gActivity = activity;

		this.fullImageListUrl = imgList;
	}

	@Override
	public int getCount() {
		
		System.out.println("filename length--" +fullImageListUrl.size());

		return this.fullImageListUrl.size();
	}

	@Override
	public boolean isViewFromObject(View view, Object object) {

		return view == ((LinearLayout) object);	
	}

	@Override
	public Object instantiateItem(ViewGroup container, int position) {

		//		TouchImageView imgDisplay;

		layoutInflater = (LayoutInflater) gActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		View viewLayout = layoutInflater.inflate(R.layout.full_screen_image, container, false);

		File SDCardRoot = Environment.getExternalStorageDirectory().getAbsoluteFile();

		if (fullImageListUrl != null && !fullImageListUrl.isEmpty()) {

			File imgFile = new File(SDCardRoot, fullImageListUrl.get(position));

			System.out.println("imgFile---"+imgFile);

			System.out.println("fullImageListUrl---"+ fullImageListUrl);

			if (imgFile.exists()) {

				//imageFetcher.loadImage(file.getAbsoluteFile(), bmImage);

				Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());

				imageDisplay = (ImageView) viewLayout.findViewById(R.id.goldGridimgDisplay);

				imageDisplay.setImageBitmap(myBitmap);
			}

			/*imageDisplay = (ImageView) viewLayout.findViewById(R.id.goldGridimgDisplay);

		BitmapFactory.Options options = new BitmapFactory.Options();

		options.inPreferredConfig = Bitmap.Config.ARGB_8888;

		Bitmap bitmap = BitmapFactory.decodeFile(fullImageListUrl.get(position), options);

		imageDisplay.setImageBitmap(bitmap);*/
		}
		/*goldItemsView = (TextView) gActivity.findViewById(R.id.goldItemDetails);

		goldItemsView.setText(filename);*/

		((ViewPager) container).addView(viewLayout);

		return viewLayout;
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {

		((ViewPager) container).removeView((LinearLayout) object);
	}
}
