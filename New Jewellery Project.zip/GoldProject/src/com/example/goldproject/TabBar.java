package com.example.goldproject;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.ActionBarActivity;
import android.app.ActionBar;
import android.app.FragmentTransaction;
import android.app.ActionBar.Tab;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TabHost.TabSpec;

public class TabBar extends FragmentActivity {

	private static final String TAB_1_TAG = "tab_1";
	private static final String TAB_2_TAG = "tab_2";
	private static final String TAB_3_TAG = "tab_3";
	private static final String TAB_4_TAG = "tab_4";
	private static final String TAB_5_TAG = "tab_5";
	private static final String TAB_6_TAG = "tab_6";

	private FragmentTabHost mTabHost;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tab_bar);
		InitView();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	private void InitView() {

		mTabHost = (FragmentTabHost)findViewById(android.R.id.tabhost);

		mTabHost.setup(this, getSupportFragmentManager(), R.id.realtabcontent);

		mTabHost.addTab(setIndicator(TabBar.this,mTabHost.newTabSpec(TAB_1_TAG), R.drawable.tab_indicator_gen,"Home",R.drawable.bang2),Tab1Container.class,null);

		mTabHost.addTab(setIndicator(TabBar.this,mTabHost.newTabSpec(TAB_2_TAG), R.drawable.tab_indicator_gen,"Gold",R.drawable.bang2),Tab2Container.class,null);

		mTabHost.addTab(setIndicator(TabBar.this,mTabHost.newTabSpec(TAB_3_TAG), R.drawable.tab_indicator_gen,"Diamond",R.drawable.bang2),Tab3Container.class,null);

		mTabHost.addTab(setIndicator(TabBar.this,mTabHost.newTabSpec(TAB_4_TAG), R.drawable.tab_indicator_gen,"Silver",R.drawable.bang2),Tab4Container.class,null);

		mTabHost.addTab(setIndicator(TabBar.this,mTabHost.newTabSpec(TAB_5_TAG), R.drawable.tab_indicator_gen,"Platinum",R.drawable.bang2),Tab5Container.class,null);

		mTabHost.addTab(setIndicator(TabBar.this,mTabHost.newTabSpec(TAB_6_TAG), R.drawable.tab_indicator_gen,"Settings",R.drawable.bang2),Tab6Container.class,null);
	}

	@Override
	public void onBackPressed() {

		boolean isPopFragment = false;
		String currentTabTag = mTabHost.getCurrentTabTag();

		if (currentTabTag.equals(TAB_1_TAG)) {
			isPopFragment = ((BaseContainerFragment)getSupportFragmentManager().findFragmentByTag(TAB_1_TAG)).popFragment();
		} else if (currentTabTag.equals(TAB_2_TAG)) {
			isPopFragment = ((BaseContainerFragment)getSupportFragmentManager().findFragmentByTag(TAB_2_TAG)).popFragment();
		}
		else if (currentTabTag.equals(TAB_3_TAG)) {
			isPopFragment = ((BaseContainerFragment)getSupportFragmentManager().findFragmentByTag(TAB_3_TAG)).popFragment();
		}

		if (!isPopFragment) {
			finish();
		}
	}

	private TabSpec setIndicator(Context ctx, TabSpec spec, int resid, String string, int genresIcon) {
		View v = LayoutInflater.from(ctx).inflate(R.layout.tab_item, null);
		v.setBackgroundResource(resid);
		TextView tv = (TextView)v.findViewById(R.id.txt_tabtxt);
		ImageView img = (ImageView)v.findViewById(R.id.img_tabtxt);

		tv.setText(string);
		img.setBackgroundResource(genresIcon);
		return spec.setIndicator(v);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.tab_bar, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
