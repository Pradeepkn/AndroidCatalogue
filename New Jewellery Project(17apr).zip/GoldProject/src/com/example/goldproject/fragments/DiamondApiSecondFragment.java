package com.example.goldproject.fragments;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.goldproject.DiamondFullScreenImage;
import com.example.goldproject.DiamondSegmentedRadioGroup;
import com.example.goldproject.R;
import com.example.goldproject.jewellerymodels.DiamondItems;
import com.example.goldproject.jewellerymodels.DiamondProducts;
import com.example.goldproject.util.cache.ImageFetcher;
import dev.dworks.libs.astickyheader.SimpleSectionedGridAdapter;
import dev.dworks.libs.astickyheader.SimpleSectionedGridAdapter.Section;
import dev.dworks.libs.astickyheader.ui.SquareImageView;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class DiamondApiSecondFragment extends Fragment implements OnClickListener, RadioGroup.OnCheckedChangeListener {

	private DiamondAdapter dAdapter;

	private GridView diamondGridView;

	private Activity mDiamondApi2;

	public Context context;

	private Toast mToast;

	private ImageFetcher imageFetcher;

	//private ViewFlipper flipper;

	private DiamondSegmentedRadioGroup diamondSegmentText;

	private SeekBar seekbar1; //Your SeekBar

	int value;        //The SeekBar value output

	private TextView result;  //The TextView which will display the result

	protected static final String TAG = "DiamondApiFragment2";

	private SimpleSectionedGridAdapter mSectionedGridAdapter;
	/*
	private Animation inFromRightAnimation() {

		Animation inFromRight = new TranslateAnimation(

				Animation.RELATIVE_TO_PARENT,  +1.0f, Animation.RELATIVE_TO_PARENT,  0.0f,

				Animation.RELATIVE_TO_PARENT,  0.0f, Animation.RELATIVE_TO_PARENT,   0.0f
				);
		inFromRight.setDuration(500);

		inFromRight.setInterpolator(new AccelerateInterpolator());

		return inFromRight;
	}*/

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		System.out.println("diamondAPIFragment onCreate().....");
	}

	@Override
	public void onAttach(Activity activity) {

		super.onAttach(activity);

		mDiamondApi2 = activity;

		imageFetcher = new ImageFetcher(activity, 50);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.diamond_row1, container, false);

		initLoginComponents(view);

		return view;
	}

	private void initLoginComponents(View view) {

	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {

		super.onActivityCreated(savedInstanceState);

		/*flipper = (ViewFlipper) getActivity().findViewById(R.id.diamondFlipper1);

		ImageView imageView = (ImageView) getActivity().findViewById(R.id.diamondItemsBackImageView4);

		imageView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				flipper.setInAnimation(inFromRightAnimation());

				flipper.showNext();
			}
		});*/

		seekbar1 = (SeekBar) getActivity().findViewById(R.id.diamondSeekBar);

		result = (TextView) getActivity().findViewById(R.id.diamondPriceResult);

		//set change listener
		seekbar1.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

				value = progress;

				result.setText (" "+value);

				System.out.println("max value:"+value);
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {

			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {

			}
		});

		diamondSegmentText = (DiamondSegmentedRadioGroup) getActivity().findViewById(R.id.diamondsegment_text);

		diamondSegmentText.setOnCheckedChangeListener(this);

		mToast = Toast.makeText(mDiamondApi2, "", Toast.LENGTH_SHORT);

		new JSONAsyncDiamondTask().execute("http://brinvents.com/jewellery/api/ListOfProducts/retrive.json?type=Diamond");

		diamondGridView =  (GridView) getActivity().findViewById(R.id.stickyGridHeadersDiamondGridView1);

		dAdapter = new DiamondAdapter(mDiamondApi2);

		mSectionedGridAdapter = new SimpleSectionedGridAdapter(mDiamondApi2, dAdapter, R.layout.grid_item_header, R.id.header_layout, R.id.header);

		mSectionedGridAdapter.setGridView(diamondGridView);

		diamondGridView.setAdapter(mSectionedGridAdapter);
	}

	class JSONAsyncDiamondTask extends AsyncTask<String, Void, ArrayList<DiamondProducts>> {

		ProgressDialog dialog;

		@Override
		protected void onPreExecute() {

			super.onPreExecute();

			dialog = new ProgressDialog(mDiamondApi2);

			dialog.setMessage("LoadingImages, please wait");

			dialog.setTitle("Connecting server");

			dialog.show();

			dialog.setCancelable(false);
		}

		@Override
		protected ArrayList<DiamondProducts> doInBackground(String... urls) {

			try {
				HttpGet httpGet = new HttpGet(urls[0]);

				HttpClient httpclient = new DefaultHttpClient();

				HttpResponse response = httpclient.execute(httpGet);

				int status = response.getStatusLine().getStatusCode();

				if (status == 200) {

					HttpEntity entity = response.getEntity();

					String data = EntityUtils.toString(entity);

					JSONObject json = new JSONObject(data);

					System.out.println("response from the server-----------"+json);

					JSONObject result = json.getJSONObject("Result");

					int errorCode = result.getInt("errorCode");

					System.out.println("ERROR_CODE->"+errorCode);

					String errorMessage = result.getString("errorMessage");

					System.out.println("ERROR_MESSAGE->"+errorMessage);

					int statusCode = result.getInt("statusCode");

					System.out.println("STATUS_CODE->"+statusCode);

					//jsonarray parse for listOfItems
					JSONArray jarray = result.getJSONArray("listOfItems");

					ArrayList<DiamondProducts> productList = new ArrayList<DiamondProducts>();

					for (int i = 0; i < jarray.length(); i++) {

						JSONObject jsonObj = jarray.getJSONObject(i);

						//jsonarray parse for products
						JSONArray jarray1 = jsonObj.getJSONArray("products");

						for (int j = 0; j < jarray1.length(); j++) {

							JSONObject products = jarray1.optJSONObject(j);

							if(products == null) {

								continue;
							}
							//jsonarray parse for items
							JSONArray itemJsonArray = products.getJSONArray("items");

							ArrayList<DiamondItems> items = new ArrayList<DiamondItems>();

							for (int k = 0; k < itemJsonArray.length(); k++) {

								JSONObject itemObject = itemJsonArray.getJSONObject(k);

								if(itemObject == null) {

									continue;
								}
								DiamondItems item = new DiamondItems();

								item.name = itemObject.optString("name");
								item.jewelleryType = itemObject.optString("jewellery_type_name");
								item.gender = itemObject.optString("gender_name");
								item.style = itemObject.optString("wearing_style_name");
								item.designType = itemObject.optString("design_type_name");
								item.clarity = itemObject.optString("clarity_name");
								item.color = itemObject.optString("color_name");
								item.size = itemObject.optString("ring_size_name");
								item.url = itemObject.optString("uri");
								item.price = itemObject.optString("price");

								items.add(item);
							}
							String productName = products.optString("PT");

							if((TextUtils.isEmpty(productName) != true) && (items.size() > 0)) {

								DiamondProducts product = new DiamondProducts();

								product.productName = productName;

								product.items = items;

								productList.add(product);
							}
						}
					}
					return productList;
				}
			} catch (ParseException e1) {

				e1.printStackTrace();

			} catch (IOException e) {

				e.printStackTrace();

			} catch (JSONException e) {

				e.printStackTrace();
			}
			return null;
		}

		protected void onPostExecute(ArrayList<DiamondProducts> result) {

			dialog.dismiss();

			if(result == null) {

				return;
			}
			dAdapter.notifyDataSetChanged();

			final ArrayList<Section> sections = new ArrayList<Section>();

			final ArrayList<DiamondItems> items = new ArrayList<DiamondItems>();

			for (int i = 0; i < result.size(); i++) {

				DiamondProducts product = result.get(i);

				if(product == null || product.items == null) {

					continue;
				}

				sections.add(new Section(items.size(), product.productName));

				items.addAll(product.items);
			}

			mSectionedGridAdapter = new SimpleSectionedGridAdapter(mDiamondApi2, dAdapter, R.layout.grid_item_header, R.id.header_layout, R.id.header);

			mSectionedGridAdapter.setGridView(diamondGridView);

			mSectionedGridAdapter.setSections(sections.toArray(new Section[0]));

			diamondGridView.setAdapter(mSectionedGridAdapter);

			dAdapter.setItems(items);
		}
	} 
	private class DiamondAdapter extends BaseAdapter {

		private LayoutInflater mInflater;

		private ArrayList<DiamondItems> mDiamondItems = new ArrayList<DiamondItems>();

		public DiamondAdapter(Context context) {

			mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}

		public void setItems(ArrayList<DiamondItems> items) {

			mDiamondItems.clear();

			if(items != null) {

				mDiamondItems.addAll(items);
			}

			notifyDataSetChanged();
		}

		@Override
		public int getCount() {

			return mDiamondItems.size();
		}

		@Override
		public Object getItem(int position) {

			return position;
		}

		@Override
		public long getItemId(int position) {

			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			final DiamondItems items = mDiamondItems.get(position);

			SquareImageView image;

			//View v = convertView;

			if (convertView == null) {

				convertView = mInflater.inflate(R.layout.diamond_row, parent, false);
			}

			image = ViewHolder.get(convertView, R.id.diamondImageLogo1);

			image.setImageResource(R.drawable.ic_launcher);

			System.out.println("position----"+position + " URL " + items.url);

			//Returns the string representation of the given int.
			String filename=String.valueOf(items.url.hashCode());

			System.out.println("filename hashcode value---"+filename);

			// get the images from url and store it in sdcard device memory
			updateImageView(image, filename, items.url);

			image.setOnClickListener(new OnDiamondImageClickListener(filename));

			return convertView;
		}

		class OnDiamondImageClickListener implements OnClickListener {

			String diamondImgPostion;

			// constructor
			public OnDiamondImageClickListener(String position) {

				this.diamondImgPostion = position;
			}

			@Override
			public void onClick(View v) {
				// on selecting grid view image
				// launch full screen activity
				Intent i = new Intent(getActivity().getApplicationContext(), DiamondFullScreenImage.class);

				i.putExtra("diamondimgposition", diamondImgPostion);

				i.putExtra("diamonditems", mDiamondItems);

				mDiamondApi2.startActivity(i);
			}
		}
	}

	public static  class ViewHolder {

		@SuppressWarnings("unchecked")
		public static <T extends View> T get(View view, int id) {

			SparseArray<View> viewHolder = (SparseArray<View>) view.getTag();

			if (viewHolder == null) {

				viewHolder = new SparseArray<View>();

				view.setTag(viewHolder);
			}
			View childView = viewHolder.get(id);

			if (childView == null) {

				childView = view.findViewById(id);

				viewHolder.put(id, childView);
			}
			return (T) childView;
		}
	}

	public void updateImageView(ImageView bmImage, String filename, String url) {

		try {
			File SDCardRoot = Environment.getExternalStorageDirectory().getAbsoluteFile();
			//create a new file, specifying the path, and the filename
			//which we want to save the file as.
			//      String filename="downloadedFile.png";  
			File file = new File(SDCardRoot,filename);

			if(file.exists()) {

				imageFetcher.loadImage(file.getAbsoluteFile(), bmImage);

			} else {

				new DownloadGoldImageTask1(bmImage, filename).execute(url);
			}
		} catch (Exception e) {

			new DownloadGoldImageTask1(bmImage, filename).execute(url);
		}
	}

	public class DownloadGoldImageTask1 extends AsyncTask<String, Void, String> {

		ImageView bmImage;

		private String mFileName;

		public DownloadGoldImageTask1(ImageView bmImage, String filename) {

			this.bmImage = bmImage;

			this.mFileName = filename;
		}

		@Override
		protected String doInBackground(String... urls) {

			String urldisplay = urls[0];

			Bitmap bitmap = null;

			File SDCardRoot = Environment.getExternalStorageDirectory().getAbsoluteFile();

			System.out.println("SDCardRoot : " + SDCardRoot + " mFileName : " + mFileName);

			File file = new File(SDCardRoot, mFileName);

			try {

				file.createNewFile();

			} catch (IOException e1) {

				e1.printStackTrace();
			}

			try {

				//set the download URL, a url that points to a file on the internet
				//this is the file to be downloaded
				URL url = new URL(urls[0]);

				System.out.println("url..."+url);

				//create the new connection
				HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

				//set up some things on the connection
				urlConnection.setRequestMethod("GET");

				urlConnection.setDoOutput(true);

				//and connect!
				urlConnection.connect();

				InputStream in = new java.net.URL(urldisplay).openStream();

				FileOutputStream os = new FileOutputStream(file);

				int len;

				byte[] buffer = new byte[10 * 1024];//10MB

				while ((len = in.read(buffer)) != -1) {

					os.write(buffer, 0, len);
				}

				os.flush();

				try {
					in.close();

					os.close();
				} catch (IOException ex) {
					// ex.printStackTrace();
				}

				bitmap = BitmapFactory.decodeStream(in);
				//catch some possible errors...

			} catch (MalformedURLException e) {

				e.printStackTrace();

			} catch (IOException e) {

				e.printStackTrace();
			}
			return file.getAbsolutePath();
		}
		// Sets the Bitmap returned by doInBackground
		@Override
		protected void onPostExecute(String result) {

			imageFetcher.loadImage(result, bmImage);
		}
	}

	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {

		if (group == diamondSegmentText) {

			if (checkedId == R.id.diamond_button_one) {

				mToast.setText("Price");

				mToast.show();
			} else if (checkedId == R.id.diamond_button_two) {

				mToast.setText("Purity");

				mToast.show();
			}  else if (checkedId == R.id.diamond_button_three) {

				mToast.setText("Weight");

				mToast.show();
			} 
		}
	}

	@Override
	public void onClick(View v) {

	}
}
