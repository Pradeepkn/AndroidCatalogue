package com.example.goldproject.fragments;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.goldproject.R;
import com.example.goldproject.SegmentedRadioGroup;
import com.example.goldproject.SilverFullScreenImage;
import com.example.goldproject.jewellerymodels.SilverItems;
import com.example.goldproject.jewellerymodels.SilverProducts;
import com.example.goldproject.util.cache.ImageFetcher;

import dev.dworks.libs.astickyheader.SimpleSectionedGridAdapter;
import dev.dworks.libs.astickyheader.SimpleSectionedGridAdapter.Section;
import dev.dworks.libs.astickyheader.ui.SquareImageView;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class SilverApiSecondFragment extends Fragment implements OnClickListener, RadioGroup.OnCheckedChangeListener {

	private SilverAdapter sAdapter;

	private GridView silverGridView;

	public Activity mSilverApi2;

	public Context context;

	private Toast mToast;

	private ImageFetcher imageFetcher;

	private SegmentedRadioGroup silverSegmentText;

	//declare variables
	private SeekBar seekbar1; //Your SeekBar

	int value;        //The SeekBar value output

	private TextView result;  //The TextView which will display the result

	protected static final String TAG = "SilverApiFragment2";

	private SimpleSectionedGridAdapter mSectionedGridAdapter;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		System.out.println("silverAPIFragment onCreate().....");
	}

	@Override
	public void onAttach(Activity activity) {

		super.onAttach(activity);

		mSilverApi2 = activity;

		/**
		 * Initialize providing a single target image size (used for both width and height);
		 * 
		 * @param context
		 * @param imageSize
		 */
		imageFetcher = new ImageFetcher(activity, 50);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.silver_row1, container, false);

		initLoginComponents(view);

		return view;
	}

	private void initLoginComponents(View view) {

	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {

		super.onActivityCreated(savedInstanceState);

		seekbar1 = (SeekBar) getActivity().findViewById(R.id.SilevrSeekBar1);

		result = (TextView) getActivity().findViewById(R.id.silverPriceResult);

		//set change listener
		seekbar1.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

				value = progress;

				result.setText (" "+value);

				System.out.println("max value:"+value);
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {

			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {

			}
		});

		silverSegmentText = (SegmentedRadioGroup) getActivity().findViewById(R.id.silverSegment_text);

		silverSegmentText.setOnCheckedChangeListener(this);

		mToast = Toast.makeText(mSilverApi2, "", Toast.LENGTH_SHORT);

		new JSONAsyncGoldTask().execute("http://brinvents.com/jewellery/api/ListOfProducts/retrive.json?type=Silver");

		silverGridView = (GridView) mSilverApi2.findViewById(R.id.stickyGridHeadersSilverGridView1);

		sAdapter = new SilverAdapter(mSilverApi2);

		mSectionedGridAdapter = new SimpleSectionedGridAdapter(mSilverApi2, sAdapter, R.layout.grid_item_header, R.id.header_layout, R.id.header);

		mSectionedGridAdapter.setGridView(silverGridView);

		silverGridView.setAdapter(mSectionedGridAdapter);
	}

	class JSONAsyncGoldTask extends AsyncTask<String, Void, ArrayList<SilverProducts>> {

		ProgressDialog dialog;

		@Override
		protected void onPreExecute() {

			super.onPreExecute();

			dialog = new ProgressDialog(mSilverApi2);

			dialog.setMessage("LoadingImages, please wait");

			dialog.setTitle("Connecting server");

			dialog.show();

			dialog.setCancelable(false);
		}

		@Override
		protected ArrayList<SilverProducts> doInBackground(String... urls) {

			try {

				HttpGet httpGet = new HttpGet(urls[0]);

				HttpClient httpclient = new DefaultHttpClient();

				HttpResponse response = httpclient.execute(httpGet);

				int status = response.getStatusLine().getStatusCode();

				if (status == 200) {

					HttpEntity entity = response.getEntity();

					String data = EntityUtils.toString(entity);

					JSONObject json = new JSONObject(data);

					System.out.println("response from the server-----------"+json);

					JSONObject result = json.getJSONObject("Result");

					int errorCode = result.getInt("errorCode");

					System.out.println("ERROR_CODE->"+errorCode);

					String errorMessage = result.getString("errorMessage");

					System.out.println("ERROR_MESSAGE->"+errorMessage);

					int statusCode = result.getInt("statusCode");

					System.out.println("STATUS_CODE->"+statusCode);

					//jsonarray parse for listOfItems
					JSONArray jarray = result.getJSONArray("listOfItems");

					//create an array list for Gold product array
					ArrayList<SilverProducts> productList = new ArrayList<SilverProducts>();

					for (int i = 0; i < jarray.length(); i++) {

						JSONObject jsonObj = jarray.getJSONObject(i);

						//jsonarray parse for products
						JSONArray jarray1 = jsonObj.getJSONArray("products");

						for (int j = 0; j < jarray1.length(); j++) {

							JSONObject products  = jarray1.optJSONObject(j);

							if(products == null) {

								continue;
							}

							//jsonarray parse for items
							JSONArray itemJsonArray  = products.getJSONArray("items");

							ArrayList<SilverItems> items = new ArrayList<SilverItems>();

							for (int k = 0; k < itemJsonArray.length(); k++) {

								final JSONObject itemObject = itemJsonArray.optJSONObject(k);

								if(itemObject == null) {

									continue;
								}

								SilverItems item = new SilverItems();

								item.name = itemObject.optString("name");
								item.jewelleryType = itemObject.optString("jewellery_type_name");
								item.gender = itemObject.optString("gender_name");
								item.style = itemObject.optString("wearing_style_name");
								item.designType = itemObject.optString("design_type_name");
								item.clarity = itemObject.optString("clarity_name");
								item.color = itemObject.optString("color_name");
								item.size = itemObject.optString("ring_size_name");
								item.url = itemObject.optString("uri");
								item.price = itemObject.optString("price");

								items.add(item);
							}
							String productName = products.optString("PT");

							if((TextUtils.isEmpty(productName) != true) && (items.size() > 0)) {

								SilverProducts product = new SilverProducts();

								product.productName = productName;

								product.items = items;

								productList.add(product);
							}
						}
					}
					return productList;
				}
			} catch (ParseException e1) {

				e1.printStackTrace();

			} catch (IOException e) {

				e.printStackTrace();

			} catch (JSONException e) {

				e.printStackTrace();
			}
			return null;
		}

		protected void onPostExecute(ArrayList<SilverProducts> result) {

			dialog.dismiss();

			if(result == null) {

				return;
			}

			sAdapter.notifyDataSetChanged();

			final ArrayList<Section> sections = new ArrayList<Section>();

			final ArrayList<SilverItems> items = new ArrayList<SilverItems>();

			for (int i = 0; i < result.size(); i++) {

				System.out.println("SilverProducts size--"+result.size());

				SilverProducts product = result.get(i);

				if(product == null || product.items == null) {

					continue;
				}

				sections.add(new Section(items.size(), product.productName));

				items.addAll(product.items);
			}

			mSectionedGridAdapter = new SimpleSectionedGridAdapter(mSilverApi2, sAdapter, R.layout.grid_item_header, R.id.header_layout, R.id.header);

			mSectionedGridAdapter.setGridView(silverGridView);

			mSectionedGridAdapter.setSections(sections.toArray(new Section[0]));

			silverGridView.setAdapter(mSectionedGridAdapter);

			sAdapter.setItems(items);
		}
	}

	private class SilverAdapter extends BaseAdapter {

		private LayoutInflater mInflater;

		private ArrayList<SilverItems> mSilverItems = new ArrayList<SilverItems>();

		public SilverAdapter(Context context) {

			mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}

		public void setItems(ArrayList<SilverItems> items) {

			mSilverItems.clear();

			if(items != null) {

				mSilverItems.addAll(items);
			}

			notifyDataSetChanged();
		}

		@Override
		public int getCount() {

			//		return goldList.size();
			return mSilverItems.size();
		}

		@Override
		public Object getItem(int position) {

			return position;
		}

		@Override
		public long getItemId(int position) {

			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			final SilverItems items = mSilverItems.get(position);

			SquareImageView image;

			//View v = convertView;

			if (convertView == null) {

				convertView = mInflater.inflate(R.layout.silver_row, parent, false);
			}

			image = ViewHolder.get(convertView, R.id.SilverImageLogo1);

			image.setImageResource(R.drawable.ic_launcher);

			System.out.println("position----"+position + " URL " + items.url);

			//Returns the string representation of the given int.
			String filename = String.valueOf(items.url.hashCode());

			// get the images from url and store it in sdcard device memory
			updateImageView(image, filename, items.url);

			image.setOnClickListener(new OnSilverImageClickListener(filename));

			return convertView;
		}

		class OnSilverImageClickListener implements OnClickListener {

			String silverImgPostion;

			// constructor
			public OnSilverImageClickListener(String position) {

				this.silverImgPostion = position;
			}

			@Override
			public void onClick(View v) {
				// on selecting grid view image
				// launch full screen activity
				Intent i = new Intent(getActivity().getApplicationContext(), SilverFullScreenImage.class);

				i.putExtra("silverimgposition", silverImgPostion);

				i.putExtra("silveritems", mSilverItems);

				mSilverApi2.startActivity(i);
			}
		}
	}

	public static  class ViewHolder {

		@SuppressWarnings("unchecked")
		public static <T extends View> T get(View view, int id) {

			SparseArray<View> viewHolder = (SparseArray<View>) view.getTag();

			if (viewHolder == null) {

				viewHolder = new SparseArray<View>();

				view.setTag(viewHolder);
			}
			View childView = viewHolder.get(id);

			if (childView == null) {

				childView = view.findViewById(id);

				viewHolder.put(id, childView);
			}
			return (T) childView;
		}
	}

	public void updateImageView(ImageView bmImage, String filename, String url) {

		try {

			File SDCardRoot = Environment.getExternalStorageDirectory().getAbsoluteFile();

			//create a new file, specifying the path, and the filename
			//which we want to save the file as.
			File file = new File(SDCardRoot,filename);

			if(file.exists()) {

				imageFetcher.loadImage(file.getAbsoluteFile(), bmImage);

			} else {

				new DownloadGoldImageTask1(bmImage, filename).execute(url);
			}
		} catch (Exception e) {

			new DownloadGoldImageTask1(bmImage, filename).execute(url);
		}
	}

	public class DownloadGoldImageTask1 extends AsyncTask<String, Void, String> {

		ImageView bmImage;

		private String mFileName;

		public DownloadGoldImageTask1(ImageView bmImage, String filename) {

			this.bmImage = bmImage;

			this.mFileName = filename;
		}

		@Override
		protected String doInBackground(String... urls) {

			String urldisplay = urls[0];

			Bitmap bitmap = null;

			File SDCardRoot = Environment.getExternalStorageDirectory().getAbsoluteFile();

			System.out.println("SDCardRoot : " + SDCardRoot + " mFileName : " + mFileName);

			File file = new File(SDCardRoot, mFileName);

			try {

				file.createNewFile();

			} catch (IOException e1) {

				e1.printStackTrace();
			}

			try {
				//set the download URL, a url that points to a file on the internet
				//this is the file to be downloaded
				URL url = new URL(urls[0]);

				System.out.println("url..."+url);

				//create the new connection
				HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

				//set up some things on the connection
				urlConnection.setRequestMethod("GET");

				urlConnection.setDoOutput(true);

				//and connect!
				urlConnection.connect();

				InputStream in = new java.net.URL(urldisplay).openStream();

				FileOutputStream os = new FileOutputStream(file);

				int len;

				byte[] buffer = new byte[10 * 1024]; //10MB

				while ((len = in.read(buffer)) != -1) {

					os.write(buffer, 0, len);
				}

				os.flush();

				try {
					in.close();

					os.close();
				} catch (IOException ex) {
					// ex.printStackTrace();
				}

				bitmap = BitmapFactory.decodeStream(in);
				//catch some possible errors...

			} catch (MalformedURLException e) {

				e.printStackTrace();

			} catch (IOException e) {

				e.printStackTrace();
			}
			return file.getAbsolutePath();
		}
		// Sets the Bitmap returned by doInBackground
		@Override
		protected void onPostExecute(String result) {

			imageFetcher.loadImage(result, bmImage);
		}
	}

	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {

		if (group == silverSegmentText) {

			if (checkedId == R.id.silver_button_one) {

				mToast.setText("Price");

				mToast.show();
			} else if (checkedId == R.id.silver_button_two) {

				mToast.setText("Purity");

				mToast.show();
			}  else if (checkedId == R.id.silver_button_three) {

				mToast.setText("Weight");

				mToast.show();
			} 
		}
	}

	@Override
	public void onClick(View v) {

	}
}
