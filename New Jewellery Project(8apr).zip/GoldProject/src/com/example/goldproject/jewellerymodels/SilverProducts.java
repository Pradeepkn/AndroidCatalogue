package com.example.goldproject.jewellerymodels;

import java.util.ArrayList;

public class SilverProducts {
	
	public String productName;

	public ArrayList<SilverItems> items;
}
