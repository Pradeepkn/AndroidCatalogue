package com.example.goldproject.jewellerymodels;

import java.util.ArrayList;

import com.example.goldproject.jewellerymodels.DiamondItems;

public class DiamondProducts {
	public String productName;

	public ArrayList<DiamondItems> items;
}
