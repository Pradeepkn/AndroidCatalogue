package com.example.goldproject.fragments;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.goldproject.R;
import com.example.goldproject.jewellerymodels.GoldItems;
import com.example.goldproject.jewellerymodels.GoldProducts;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewFlipper;

public class GoldApiFirstFragment extends Fragment {

	private Activity mGoldApi;

	private ArrayList<GoldItems> goldItemsCategory;

	private ArrayList<GoldProducts> goldProductItemsCategory;

	//	private GoldItemsAdapter gItemsAdapter;

	private String url = "http://brinvents.com/jewellery/api/ListOfProducts/retrive.json?type=Gold";

	private ViewFlipper goldFlipper;

	//	private TableLayout goldItemsLayout;

	private TextView womenTextViewRow;

	private TextView menTextViewRow;

	//	private static final String Tag_Product_Type = "PT";
	//
	//	private static final String Tag_Name = "name";
	//
	//	private static final String Tag_Gender = "gender_name";

	//	private ArrayList<HashMap<String, String>> goldItemsList;

	private Animation inFromRightAnimation() {

		Animation inFromRight = new TranslateAnimation(

				Animation.RELATIVE_TO_PARENT,  +1.0f, Animation.RELATIVE_TO_PARENT,  0.0f,

				Animation.RELATIVE_TO_PARENT,  0.0f, Animation.RELATIVE_TO_PARENT,   0.0f
				);
		inFromRight.setDuration(500);

		inFromRight.setInterpolator(new AccelerateInterpolator());

		return inFromRight;
	}

	private Animation inFromLeftAnimation() {

		Animation inFromLeft = new TranslateAnimation(

				Animation.RELATIVE_TO_PARENT,  -1.0f, Animation.RELATIVE_TO_PARENT,  0.0f,

				Animation.RELATIVE_TO_PARENT,  0.0f, Animation.RELATIVE_TO_PARENT,   0.0f
				);
		inFromLeft.setDuration(500);

		inFromLeft.setInterpolator(new AccelerateInterpolator());

		return inFromLeft;
	}

	@Override
	public void onAttach(Activity activity) {

		mGoldApi = activity;

		super.onAttach(activity);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		System.out.println("gold API on create() started.......................");
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		// Set title bar
		//		((MainFragmentActivity) getActivity()).setActionBarTitle("Gold Items");

		View view = inflater.inflate(R.layout.gold_fragment_viewflipper, container, false);

		initSignUpComponenets(view);

		return view;
	}

	private void initSignUpComponenets(View view) {

		goldFlipper = (ViewFlipper) view.findViewById(R.id.goldViewFlipperFrag1);

		//		goldItemsLayout = (TableLayout) view.findViewById(R.id.goldListItemsLayout);

		womenTextViewRow = (TextView) view.findViewById(R.id.GoldWomenItemsId);

		menTextViewRow = (TextView) view.findViewById(R.id.GoldMenId);

		final TextView womenGoldItemIdView0 = (TextView) view.findViewById(R.id.womenGoldItemId0);

		ImageView golditemsCategoryBackImage = (ImageView) view.findViewById(R.id.goldItemsCategoryBackImageView);

		TextView golditemsCategoryBackText = (TextView) view.findViewById(R.id.goldItemsCategoryBackTextView);

		ImageView goldItemsDetailsBackImage = (ImageView) view.findViewById(R.id.goldItemsDetailsBackImageView);

		TextView goldItemsDetailsBackText = (TextView) view.findViewById(R.id.goldItemsDetailsBackTextView);

		//		goldItemsList = new ArrayList<HashMap<String,String>>();

		womenTextViewRow.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				goldFlipper.setInAnimation(inFromRightAnimation());

				goldFlipper.showNext();

				//				for (int i = 0; i < goldItemsList.size(); i++) {
				//
				//					if (goldItemsList.get(i).get(Tag_Gender) == "Women") {
				//
				//						womenGoldItemIdView0.setText(goldItemsList.get(i).get(Tag_Name));
				//					}
				//				}
			}
		});

		womenGoldItemIdView0.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				goldFlipper.setInAnimation(inFromRightAnimation());

				goldFlipper.showNext();
			}
		});

		golditemsCategoryBackImage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				goldFlipper.setInAnimation(inFromLeftAnimation());

				goldFlipper.showPrevious();
			}
		});

		golditemsCategoryBackText.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				goldFlipper.setInAnimation(inFromLeftAnimation());

				goldFlipper.showPrevious();
			}
		});

		goldItemsDetailsBackImage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				goldFlipper.setInAnimation(inFromLeftAnimation());

				goldFlipper.showPrevious();
			}
		});

		goldItemsDetailsBackText.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				goldFlipper.setInAnimation(inFromLeftAnimation());

				goldFlipper.showPrevious();
			}
		});
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {

		super.onActivityCreated(savedInstanceState);

		//		goldItemsCategory = new ArrayList<GoldItems>();

		//		goldProductItemsCategory = new ArrayList<GoldProducts>();

		// Call Async task to get the gold items

		new JsonGoldItemsTask().execute();
		//
		//		ListView goldItemsListView = (ListView) getActivity().findViewById(R.id.goldItemsListView);
		//
		//		gItemsAdapter = new GoldItemsAdapter(getActivity().getApplicationContext(), R.layout.gold_fragment1_slide1, goldItemsCategory, goldProductItemsCategory);
		//
		//		goldItemsListView.setAdapter(gItemsAdapter);
	}

	private class JsonGoldItemsTask extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {

			super.onPreExecute();
			// Showing progress dialog
			//			pDialog = new ProgressDialog(mGoldApi);
			//
			//			pDialog.setMessage("Please wait...");
			//
			//			pDialog.setCancelable(false);
			//
			//			pDialog.show();
		}

		@Override
		protected Void doInBackground(Void... args) {

			System.out.println("background process strated");

			ServiceHandler serviceClient = new ServiceHandler();

			String jsonResp = serviceClient.makeServiceCall(url, ServiceHandler.GET);

			System.out.println("response from url--" + jsonResp);

			if(jsonResp != null){

				try {
					/*HttpGet httpGetreq = new HttpGet(urls[0]);

				// getting product details by making HTTP request
				HttpClient httpClient = new DefaultHttpClient();
				// check your log for json response
				//               Log.d("Login attempt", json.toString());

				HttpResponse response = httpClient.execute(httpGetreq);

				int status = response.getStatusLine().getStatusCode();

				if (status == 200) {

					HttpEntity entity = response.getEntity();

					String data = EntityUtils.toString(entity);*/

					JSONObject json = new JSONObject(jsonResp);

					System.out.println("response from the server-----------"+json);

					JSONObject result = json.getJSONObject("Result");

					int errorCode = result.getInt("errorCode");

					System.out.println("ERROR_CODE->"+errorCode);

					String errorMessage = result.getString("errorMessage");

					System.out.println("ERROR_MESSAGE->"+errorMessage);

					int statusCode = result.getInt("statusCode");

					System.out.println("STATUS_CODE->"+statusCode);

					//jsonarray parse for listOfItems
					JSONArray jarray = result.getJSONArray("listOfItems");

					// create an array list for Gold product array
					ArrayList<GoldProducts> productList = new ArrayList<GoldProducts>();

					for (int i = 0; i < jarray.length(); i++) {

						JSONObject jsonObj = jarray.getJSONObject(i);

						//jsonarray parse for products
						JSONArray jarray1 = jsonObj.getJSONArray("products");

						for (int j = 0; j < jarray1.length(); j++) {

							JSONObject products  = jarray1.optJSONObject(j);

							if (products == null) {

								continue;
							}

							//jsonarray parse for items
							JSONArray itemJsonArray  = products.getJSONArray("items");

							goldItemsCategory = new ArrayList<GoldItems>();

							for (int k = 0; k < itemJsonArray.length(); k++) {

								JSONObject itemObject = itemJsonArray.optJSONObject(k);

								if (itemObject == null) {

									continue;
								}

								GoldItems gItems = new GoldItems();

								gItems.gender = itemObject.optString("gender_name");

								goldItemsCategory.add(gItems);

								//								String name = itemObject.getString("name");
								//
								//								String genderName = itemObject.getString(Tag_Gender);

								//  hashmap for single match
								//								HashMap<String, String> goldList = new HashMap<String, String>();

								// adding each child node to HashMap key => value

								/*goldList.put(Tag_Product_Type, productItems);

								goldList.put(Tag_Name, name);

								goldList.put(Tag_Gender, genderName);

								goldItemsList.add(goldList);*/

								//								goldItemsCategory.add(gItems);
								//
								//								goldProductItemsCategory.add(gProducts);
							}
						}
					}
				}catch (JSONException e) {

					e.printStackTrace();
				} 
			}else {
				Log.e("JSON data", "didn't receive the response from JSON url");
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {

			super.onPostExecute(result);

			//			if(pDialog.isShowing());
			//
			//			pDialog.dismiss();
			//
			//			for (int i = 0; i < goldItemsList.size(); i++) {
			//
			//				System.out.println("size of goldItemsList--" + goldItemsList.size());
			//
			//				if(goldItemsList.get(i).get(Tag_Gender) == goldItemsList.get(i).get(Tag_Gender)) {

		}
	}
}
