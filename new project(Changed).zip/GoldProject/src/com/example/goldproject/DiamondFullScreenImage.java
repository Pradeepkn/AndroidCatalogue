package com.example.goldproject;

import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class DiamondFullScreenImage extends ActionBarActivity {
	
	private DiamondFullScreenImageAdapter dAdapter;

	private ViewPager viewPager;

	//private ArrayList<DiamondItems> fullImageList = new ArrayList<DiamondItems>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_diamond_full_screen_image);
		
		viewPager = (ViewPager) findViewById(R.id.diamondSinglePager1);
		
		// Get intent data
				Intent i = getIntent();

				// Selected image id
				int position = i.getExtras().getInt("position");

				Log.d("Position>>>", "Position" + position);

				dAdapter = new DiamondFullScreenImageAdapter(this);

				viewPager.setAdapter(dAdapter);

				// displaying selected image first
				viewPager.setCurrentItem(position);
	}
/*
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.diamond_full_screen_image, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}*/
}
