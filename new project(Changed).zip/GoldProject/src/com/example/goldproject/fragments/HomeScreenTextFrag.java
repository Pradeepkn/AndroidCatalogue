package com.example.goldproject.fragments;

import com.example.goldproject.R;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class HomeScreenTextFrag extends Fragment {

	Activity textActivity;

	@Override
	public void onAttach(Activity activity) {

		textActivity = activity;

		super.onAttach(activity);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		System.out.println("homescreen images textfrag started...");
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.homescreen_text_frag, container, false);

		return view;
	}
}
