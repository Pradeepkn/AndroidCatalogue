package com.example.goldproject.fragments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.goldproject.R;
import android.app.Activity;
import android.app.ProgressDialog;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class HomeScreenSlideFrag extends Fragment {

	private Activity slideActivity;

	/*final HomeScreenSlideFrag context = this;

	private JSONObject jObj;

	private String uri;

	private CustomPagerAdapter mCustomPagerAdapter;

	private ViewPager mViewPager;*/

	public int currentimageindex = 0;

	ImageView slidingimage;

	private int[] IMAGE_IDS = { R.drawable.slide1, R.drawable.slide2, R.drawable.slide3, R.drawable.slide4 };

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		System.out.println("home screen slide show on create() started....");
	}

	@Override
	public void onAttach(Activity activity) {

		super.onAttach(activity);

		slideActivity = activity;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.homescreen_slidefrag_image, container, false);

		initLoginComponents(view);

		return view;
	}

	private void initLoginComponents(View view) {

		slidingimage = (ImageView) view.findViewById(R.id.imageView_slide);

		//mViewPager = (ViewPager) view.findViewById(R.id.pager);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {

		super.onActivityCreated(savedInstanceState);

		final Handler mHandler = new Handler();

		// Create runnable for posting
		final Runnable mUpdateResults = new Runnable()
		{
			public void run()
			{
				//VM screen budget exceeds limit
				AnimateandSlideShow();
			}
		};

		int delay = 1000; // delay for 1 sec.

		int period = 3000; // repeat every 3 sec.

		Timer timer = new Timer();

		timer.scheduleAtFixedRate(new TimerTask()
		{
			public void run()
			{
				mHandler.post(mUpdateResults);
			}
		}, delay, period);
		/*new JSONAsyncTask().execute("http://brinvents.com/jewellery/api/ListOfProducts/retrive.json?type=offers");

		mCustomPagerAdapter = new CustomPagerAdapter(slideActivity);

		mViewPager.setAdapter(mCustomPagerAdapter);*/
	}

	private void AnimateandSlideShow() {

		//VM screen budget exceeds limit
		slidingimage.setImageResource(IMAGE_IDS[currentimageindex % IMAGE_IDS.length]);

		currentimageindex++;

		Animation rotateimage = AnimationUtils.loadAnimation(slideActivity, R.anim.fade_in);

		slidingimage.startAnimation(rotateimage);
	}

	// DownloadJSON AsyncTask
	/*private class JSONAsyncTask extends AsyncTask<String, Void, ArrayList<String>> {

		ProgressDialog dialog;

		@Override
		protected void onPreExecute() {

			super.onPreExecute();

			dialog = new ProgressDialog(slideActivity);

			dialog.setMessage("LoadingImages, please Wait...");

			dialog.setTitle("connecting server..");

			dialog.show();

			dialog.setCancelable(false);
		}

		@Override
		protected ArrayList<String> doInBackground(String... urls) {

			try {
				HttpGet httpGet = new HttpGet(urls[0]);

				HttpClient httpclient = new DefaultHttpClient();

				HttpResponse response = httpclient.execute(httpGet);

				// StatusLine stat = response.getStatusLine();
				int status = response.getStatusLine().getStatusCode();

				if (status == 200) {

					HttpEntity entity = response.getEntity();

					String data = EntityUtils.toString(entity);

					JSONObject jsono = new JSONObject(data);

					System.out.println("response from the server-----------"+jsono);

					// Retrieve JSON Objects from the given website URL in JSONfunctions
					JSONObject result = jsono.getJSONObject("Result");

					// Retrieve JSON Objects
					// Storing each json item in variable
					int errorCode = result.getInt("errorCode");

					System.out.println("ERROR_CODE->"+errorCode);

					String errorMessage = result.getString("errorMessage");

					System.out.println("ERROR_MESSAGE->"+errorMessage);

					int statusCode = result.getInt("statusCode");

					System.out.println("STATUS_CODE->"+statusCode);

					ArrayList<String> urlValues = new ArrayList<String>();

					// Locate the array name
					JSONArray jarray = result.getJSONArray("listOfItems");

					for (int i = 0; i < jarray.length(); i++) 
					{
						jObj = jarray.getJSONObject(i);

						uri = jObj.getString("offer_image");

						System.out.println("offer images----"+uri);

						urlValues.add(uri);
					}
					return urlValues;
				}
			} catch (ParseException e1) {

				e1.printStackTrace();

			} catch (IOException e) {

				e.printStackTrace();

			} catch (JSONException e) {

				e.printStackTrace();
			}
			return null;
		}

		protected void onPostExecute(ArrayList<String> urls) {

			dialog.cancel();

			if(urls != null) {

				mCustomPagerAdapter.setItems(urls);
			}
		}*/
}
