package com.example.jewelleryproject;

public class HomeScreen {

	private String uri;

	public HomeScreen() {
	}

	public HomeScreen(String uri){
		super();
		this.uri = uri;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

}
