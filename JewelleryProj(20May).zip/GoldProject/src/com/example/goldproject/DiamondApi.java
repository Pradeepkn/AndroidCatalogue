package com.example.goldproject;

import android.support.v7.app.ActionBarActivity;
import android.widget.TextView;
import android.content.Intent;
import android.os.Bundle;

public class DiamondApi extends ActionBarActivity {

	TextView diamondApiUserName;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_diamond_api);

		System.out.println("entering to diamond API");
		
		diamondApiUserName = (TextView) findViewById(R.id.diamondUserName);

		Intent intent = getIntent();

		String userName = intent.getStringExtra("userName");

		diamondApiUserName.setText(userName);

		getSupportActionBar().hide();
	}
}
