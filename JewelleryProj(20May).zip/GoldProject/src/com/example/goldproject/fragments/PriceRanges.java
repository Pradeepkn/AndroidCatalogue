package com.example.goldproject.fragments;

public class PriceRanges {

}
