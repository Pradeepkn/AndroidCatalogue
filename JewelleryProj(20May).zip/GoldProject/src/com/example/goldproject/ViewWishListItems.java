package com.example.goldproject;

import java.io.File;
import java.util.ArrayList;

import com.example.goldproject.jewellerymodels.GoldItems;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ViewWishListItems extends ActionBarActivity {

	String viewWishListImgPos;

	ArrayList<GoldItems> viewWishListItems;

	private ViewWishListAdapter viewWishListAdapter;

	private TextView itemName, item_price, item_purity;

	private String filename;

	private ImageView viewWishListImage;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.viewwishlistlayout);

		itemName = (TextView) findViewById(R.id.itemNameWishList);

		item_price = (TextView) findViewById(R.id.item_priceWishList);

		item_purity = (TextView) findViewById(R.id.item_purityWishList);

		Intent intent = getIntent();

		viewWishListImgPos = intent.getStringExtra("viewWishListImgPosition");

		viewWishListItems = (ArrayList<GoldItems>) intent.getSerializableExtra("viewWishListItems");

		viewWishListAdapter = new ViewWishListAdapter(ViewWishListItems.this, viewWishListImgPos);

		viewWishListAdapter.setItems(viewWishListItems);

		System.out.println("viewWishListinclick img pos--" +viewWishListImgPos);
	}

	public class ViewWishListAdapter extends BaseAdapter {

		private ArrayList<GoldItems> mGoldItem = new ArrayList<GoldItems>();

		private LayoutInflater layoutInflater;

		private Activity gActivity;

		public void setItems(ArrayList<GoldItems> item) {

			mGoldItem.clear();

			if (item != null) {

				mGoldItem.addAll(item);
			}
			notifyDataSetChanged();
		}
		public ViewWishListAdapter(Activity activity, String ViewWishListImg) {

			this.gActivity = activity;
		}

		@Override
		public int getCount() {

			return this.mGoldItem.size();
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			filename = String.valueOf(mGoldItem.get(position).url.hashCode());

			System.out.println("url filename--" +filename);

			layoutInflater = (LayoutInflater) gActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

			File SDCardRoot = Environment.getExternalStorageDirectory().getAbsoluteFile();

			if (filename != null && !filename.isEmpty()) {

				File imgFile = new File(SDCardRoot, filename);

				System.out.println("imgFile---" + imgFile);

				System.out.println("fullImageListUrl---" + filename);

				if (imgFile.exists()) {

					Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());

					viewWishListImage = (ImageView) convertView.findViewById(R.id.goldItemsWishListImg);

					viewWishListImage.setImageBitmap(myBitmap);

					itemName.setText(mGoldItem.get(position).name);

					//					item_price.setText(mGoldItem.get(position).price);

					item_purity.setText(mGoldItem.get(position).purity);
				}
			}
			return convertView;
		}
	}
}
