package com.example.goldproject.jewellerymodels;

import java.util.ArrayList;

import com.example.goldproject.jewellerymodels.PlatinumItems;

public class PlatinumProducts {
	public String productName;

	public ArrayList<PlatinumItems> items;
}
