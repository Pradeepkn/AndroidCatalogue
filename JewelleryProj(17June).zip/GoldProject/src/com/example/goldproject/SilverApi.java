package com.example.goldproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.widget.TextView;

public class SilverApi extends ActionBarActivity {

	TextView silverApiUserName;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_silver_api);

		System.out.println("entering to gold API");

		silverApiUserName = (TextView) findViewById(R.id.silverUserName);

		Intent intent = getIntent();

		String userName = intent.getStringExtra("userName");

		silverApiUserName.setText(userName);

		getSupportActionBar().hide();
	}
}
