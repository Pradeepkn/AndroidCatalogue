/** Automatically generated file. DO NOT MODIFY */
package com.tonicartos.stickygridheaders;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}