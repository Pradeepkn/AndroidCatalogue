package com.example.goldproject;

public class DetailsAdapter {

}
