package com.example.goldproject;

import java.util.ArrayList;

import android.R.string;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.widget.ImageView;

public class SingleClickImage extends Activity {

	public static String position;
	
	public ViewPager viewPager;
	
	public ArrayList<Gold> singleList;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_single_click_image);
		
		Log.d("onCreate>>", "OnCreate");

		// Get intent data
		Intent i = getIntent();

		// Selected image id
		position = i.getExtras().getString("id");

		Log.d("Position>>>", "Position" + position);

		viewPager = (ViewPager) findViewById(R.id.view_pager);
		
		singleList = new ArrayList<Gold>();
		
		ImageAdapter adapter = new ImageAdapter(this, R.layout.image_pager, singleList);
		
		viewPager.setAdapter(adapter);
	}
}
