package com.example.goldproject;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

public class GoldApi extends ActionBarActivity {
/*
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		return inflater.inflate(R.layout.activity_gold_api, container, false);
	}*/

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_gold_api);
	}
}
