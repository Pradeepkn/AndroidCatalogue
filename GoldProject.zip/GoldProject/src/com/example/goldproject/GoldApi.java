package com.example.goldproject;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

public class GoldApi extends ActionBarActivity {
	/*
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		return inflater.inflate(R.layout.activity_gold_api, container, false);
	}*/

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_gold_api);
		
		System.out.println("entering to gold API");

		getSupportActionBar().hide();
		/*ActionBar actionBar = getSupportActionBar();

		// Enabling Back navigation on Action Bar icon
		actionBar.setDisplayHomeAsUpEnabled(true);

		actionBar.setDisplayShowHomeEnabled(false);

		actionBar.setDisplayShowTitleEnabled(false);

		LayoutInflater mInflater = LayoutInflater.from(this);

		View mCustomView = mInflater.inflate(R.layout.golditems_textview, null);
		// add the custom view to the action bar
		//actionBar.setCustomView(R.layout.back_textview);

		TextView backView = (TextView) mCustomView.findViewById(R.id.goldItemsTextView);

		ImageView goldBackView = (ImageView) mCustomView.findViewById(R.id.goldBackImageView);

		TextView goldBacktextView = (TextView) mCustomView.findViewById(R.id.goldBackView);

		actionBar.setCustomView(mCustomView);

		actionBar.setDisplayShowCustomEnabled(true);*/
	}
}
