package com.example.goldproject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import com.example.goldproject.Gold;
import com.example.goldproject.R;
import com.tonicartos.widget.stickygridheaders.StickyGridHeadersSimpleAdapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class GoldAdapter extends ArrayAdapter<Gold> implements StickyGridHeadersSimpleAdapter {

	private int mHeaderResId;

	private int mItemResId;

	private ArrayList<Gold> goldList = new ArrayList<Gold>();

	private LayoutInflater inflater;

	int Resource;

	private ViewHolder holder;

	//ProgressDialog mProgressDialog;

	private Activity gActivity;

	//private int imagewidth;

	public GoldAdapter(Activity activity, int headerResId, int itemResId, ArrayList<Gold> objects) {

		super(activity, headerResId, itemResId, objects);

		System.out.println("entering gold adapter");

		inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		mHeaderResId = headerResId;

		mItemResId = itemResId;

		goldList = objects;
	}

	@Override
	public long getHeaderId(int position) {

		Gold gList = getItem(position);

		CharSequence value;

		if (gList instanceof CharSequence) {

			value = (CharSequence)gList;

		} else {

			value = gList.toString();
		}

		return value.subSequence(0, 1).charAt(0);
	}

	@Override
	public View getHeaderView(int position, View convertView, ViewGroup parent) {

		HeaderViewHolder holder;

		if (convertView == null) {

			convertView = inflater.inflate(mHeaderResId, parent, false);

			holder = new HeaderViewHolder();

			holder.textView = (TextView)convertView.findViewById(R.id.SectionZero);

			convertView.setTag(holder);
		} else {
			holder = (HeaderViewHolder)convertView.getTag();
		}

		//holder.textView.setText(goldList.get(position).getUri());
		Gold item = getItem(position);

		CharSequence string;

		if (item instanceof CharSequence) {

			string = (CharSequence)item;

		} else {
			string = item.toString();
		}
		// set header text as first char in string
		//holder.textView.setText(string);

		return convertView;
	}
	//Get a View that displays the data at the specified position in the data set
	// create a new ImageView for each item referenced by the Adapter

	@Override
	public View getView(int position, View convertView, ViewGroup parent) 
	{
		// convert view = design
		View v = convertView;

		if (v == null) {

			holder = new ViewHolder();

			v = inflater.inflate(mItemResId, null);
			//holder.goldCT = (TextView) v.findViewById(R.id.CT);
			//holder.goldPT = (TextView) v.findViewById(R.id.PT);
			holder.imageview = (ImageView) v.findViewById(R.id.GoldImageLogo1);

			//String imageList = goldList.get(position).getUri();

			//holder.imageview.setLayoutParams(new GridView.LayoutParams(100,100));

			//holder.imageview.setScaleType(ImageView.ScaleType.CENTER_CROP);

			//holder.imageview.setPadding(5, 5, 5, 5);
			/*holder.jewelleryTypeName = (TextView) v.findViewById(R.id.jewellery_type_name);
			holder.goldName = (TextView) v.findViewById(R.id.name);
			holder.genderName = (TextView) v.findViewById(R.id.gender_name);
			holder.wearingStyleName = (TextView) v.findViewById(R.id.wearing_style_name);
			holder.designTypeName = (TextView) v.findViewById(R.id.design_type_name);
			holder.colorName = (TextView) v.findViewById(R.id.color_name);
			holder.clarityName = (TextView) v.findViewById(R.id.clarity_name);
			holder.ringSizeName = (TextView) v.findViewById(R.id.ring_size_name);
			holder.price = (TextView) v.findViewById(R.id.price);*/

			v.setTag(holder);
		} else {
			holder = (ViewHolder) v.getTag();
		}
		/*Gold item = getItem(position);

        if (item instanceof CharSequence) {
            holder.imageview.setImageResource((CharSequence)item);
        } else {
            holder.textView.setText(item.toString());
        }*/
		// get screen dimensions
		//Bitmap image = decodeFile(goldList.get(position).getUri(), 100, 100);

		//holder.imageview.setScaleType(ImageView.ScaleType.CENTER_CROP);

		//holder.imageview.setLayoutParams(new GridView.LayoutParams(100,100));	

		//holder.imageview.setImageBitmap(image);

		holder.imageview.setImageResource(R.drawable.ic_launcher);

		//holder.imageview.setLayoutParams(new GridView.LayoutParams(imagewidth, imagewidth));

		System.out.println("position----"+position);

		updateImageView(holder.imageview, "goldfileName_" + position, goldList.get(position).getUri());

		holder.imageview.setOnClickListener(new OnGoldImageClickListner(position));

		//new DownloadImageTask().execute(goldList.get(position).getUri());
		// calling DownloadAndReadImage class to load and save image in sd card
		//	DownloadAndReadImage dImage = new DownloadAndReadImage(goldList.get(position).getUri());
		//holder.imageview.setImageBitmap(dImage.getBitmapImage());
		/*holder.goldCT.setText(goldList.get(position).getCT());
		holder.goldPT.setText("PT:"+goldList.get(position).getPT());
		holder.goldName.setText("name: " + goldList.get(position).getName());
		holder.jewelleryTypeName.setText("jewellerytypename:"+goldList.get(position).getJewellery_type_name());
		holder.genderName.setText("gendername: " + goldList.get(position).getGender_name());
		holder.wearingStyleName.setText("wearingstylename: " + goldList.get(position).getWearing_style_name());
		holder.designTypeName.setText("designtypename: " + goldList.get(position).getDesign_type_name());
		holder.clarityName.setText("clarityname: " + goldList.get(position).getClarity_name());
		holder.colorName.setText("colorname: " + goldList.get(position).getColor_name());
		holder.ringSizeName.setText("ringsizename: " + goldList.get(position).getRing_size_name());
		holder.price.setText("price: " + goldList.get(position).getPrice());
		 */
		return v;
	}

	public class OnGoldImageClickListner implements OnClickListener {

		int _postion;

		// constructor
		public OnGoldImageClickListner(int position) {

			this._postion = position;
		}

		@Override
		public void onClick(View v) {
			// on selecting grid view image
			// launch full screen activity
			Intent i = new Intent(gActivity, GoldFullScreenImage.class);

			i.putExtra("position", _postion);

			gActivity.startActivity(i);
		}
	}

	/*private Bitmap decodeFile(String filePath, int WIDTH, int HIGHT) {

		try {

			File f = new File(filePath);

			BitmapFactory.Options o = new BitmapFactory.Options();
			o.inJustDecodeBounds = true;
			BitmapFactory.decodeStream(new FileInputStream(f), null, o);

			final int REQUIRED_WIDTH = WIDTH;
			final int REQUIRED_HIGHT = HIGHT;
			int scale = 1;
			while (o.outWidth / scale / 2 >= REQUIRED_WIDTH
					&& o.outHeight / scale / 2 >= REQUIRED_HIGHT)
				scale *= 2;

			BitmapFactory.Options o2 = new BitmapFactory.Options();
			o2.inSampleSize = scale;
			return BitmapFactory.decodeStream(new FileInputStream(f), null, o2);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}*/

	private void updateImageView(ImageView bmImage, String filename, String url) {

		File SDCardRoot = Environment.getExternalStorageDirectory().getAbsoluteFile();
		//create a new file, specifying the path, and the filename
		//which we want to save the file as.
		//      String filename="downloadedFile.png";  
		File file = new File(SDCardRoot,filename);

		if(file.exists()) {

			Bitmap myBitmap = BitmapFactory.decodeFile(file.getAbsolutePath());

			bmImage.setImageBitmap(myBitmap);

		} else {

			new DownloadGoldImageTask1(bmImage, filename).execute(url);
		}
	}

	public class DownloadGoldImageTask1 extends AsyncTask<String, Void, Bitmap> {
		
		ImageView bmImage;

		private String mFileName;

		public DownloadGoldImageTask1(ImageView bmImage, String filename) {

			this.bmImage = bmImage;

			this.mFileName = filename;
		}

		@Override
		protected Bitmap doInBackground(String... urls) {

			String urldisplay = urls[0];

			Bitmap bitmap = null;

			try {
				//set the download URL, a url that points to a file on the internet
				//this is the file to be downloaded
				URL url = new URL(urls[0]);

				System.out.println("url..."+url);
				//create the new connection
				HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

				//set up some things on the connection
				urlConnection.setRequestMethod("GET");

				urlConnection.setDoOutput(true);

				//and connect!
				urlConnection.connect();

				//set the path where we want to save the file
				//in this case, going to save it on the root directory of the
				//sd card.
				//return the path to the root of the external storage(SDcard).
				File SDCardRoot = Environment.getExternalStorageDirectory().getAbsoluteFile();
				//create a new file, specifying the path, and the filename
				//which we want to save the file as.
				//              String filename="downloadedFile.png";  
				File file = new File(SDCardRoot,mFileName);

				if(file.createNewFile())
				{
					file.createNewFile();
				}
				SDCardRoot.mkdir();
				//this will be used to write the downloaded data into the file we created
				FileOutputStream fileOutput = new FileOutputStream(file);

				//this will be used in reading the data from the internet
				InputStream inputStream = urlConnection.getInputStream();

				//this is the total size of the file
				int totalSize = urlConnection.getContentLength();

				System.out.println("total size......"+totalSize);
				//variable to store total downloaded bytes
				int downloadedSize = 0;

				//create a buffer...
				byte[] buffer = new byte[1024];

				int bufferLength = 0; //used to store a temporary size of the buffer

				//now, read through the input buffer and write the contents to the file
				while ((bufferLength = inputStream.read(buffer)) > 0 ) {
					//add the data in the buffer to the file in the file output stream (the file on the sd card)
					fileOutput.write(buffer, 0, bufferLength);
					//add up the size so we know how much is downloaded
					downloadedSize += bufferLength;
					//                    Log.i("Progress:","downloadedSize:"+downloadedSize+"totalSize:"+ totalSize) ;
					//this is where you would do something to report the progress, like this maybe
					//updateProgress(downloadedSize, totalSize);
				}
				//close the output stream when done
				fileOutput.close();

				InputStream in = new java.net.URL(urldisplay).openStream();

				bitmap = BitmapFactory.decodeStream(in);
				//catch some possible errors...
			} catch (MalformedURLException e) {

				e.printStackTrace();

			} catch (IOException e) {

				e.printStackTrace();
			}
			return bitmap;
		}
		// Sets the Bitmap returned by doInBackground
		@Override
		protected void onPostExecute(Bitmap result) {

			bmImage.setImageBitmap(result);
		}
	}

	static class ViewHolder {

		public ImageView imageview;
		/*public TextView goldCT;
		public TextView goldPT;
		public TextView goldName;
		public TextView jewelleryTypeName;
		public TextView genderName;
		public TextView wearingStyleName;
		public TextView designTypeName;
		public TextView clarityName;
		public TextView colorName;
		public TextView ringSizeName;
		public TextView price;*/
	}

	protected class HeaderViewHolder {

		public TextView textView;
	}
}
