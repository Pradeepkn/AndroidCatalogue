package com.example.goldproject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import at.technikum.mti.fancycoverflow.FancyCoverFlow;

public class HomeScreenImagesApi extends Activity implements OnClickListener{

	/*ArrayList<HomeScreen> homeList;
	HomeScreenAdapter adapter;*/
	JSONObject jObj;

	Dialog cDialog;
	
	final Context context = this;
	//	public static Drawable drawable = null;
	//private Activity mHomeScreen;

	String uri;

	//ImageView imageView;

	private FancyCoverFlow fancyCoverFlow;

	private MyAdapter mAdapter;

	public int currentimageindex = 0;

	ImageView slidingimage;

	private int[] IMAGE_IDS = { R.drawable.slide1, R.drawable.slide2, R.drawable.slide3, R.drawable.slide4, R.drawable.slide5, R.drawable.slide6,R.drawable.slide7 };

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_home_screen_images_api);

		EditText priceEditText = (EditText) findViewById(R.id.todaysPrice);

		EditText weightEditText = (EditText) findViewById(R.id.WeightInGrams);

		EditText wastageEditText = (EditText) findViewById(R.id.WastageCharges);

		EditText makingEditText = (EditText) findViewById(R.id.MakingCharges);

		EditText discountEditText = (EditText) findViewById(R.id.Discount);

		EditText vatEditText = (EditText) findViewById(R.id.VAT);

		Button calculateButton = (Button) findViewById(R.id.CalculateId);

		//add calculate button listner
		calculateButton.setOnClickListener(this);

		slidingimage = (ImageView) findViewById(R.id.imageView_slide);

		this.fancyCoverFlow = (FancyCoverFlow) findViewById(R.id.fancyCoverFlow);

		final Handler mHandler = new Handler();

		// Create runnable for posting
		final Runnable mUpdateResults = new Runnable()
		{
			public void run()
			{
				AnimateandSlideShow();
			}
		};

		int delay = 1000; // delay for 1 sec.

		int period = 3000; // repeat every 3 sec.

		Timer timer = new Timer();

		timer.scheduleAtFixedRate(new TimerTask()
		{
			public void run()
			{
				mHandler.post(mUpdateResults);
			}
		}, delay, period);

		//creation of fancy cover flow.

		mAdapter = new MyAdapter();

		/*fancyCoverFlow.setReflectionEnabled(true);

        fancyCoverFlow.setReflectionRatio(0.3f);

        fancyCoverFlow.setReflectionGap(0);
		 */
		this.fancyCoverFlow.setAdapter(mAdapter);

		this.fancyCoverFlow.setUnselectedAlpha(.3f);

		this.fancyCoverFlow.setUnselectedSaturation(0.0f);

		this.fancyCoverFlow.setUnselectedScale(0.4f);

		this.fancyCoverFlow.setSpacing(50);

		this.fancyCoverFlow.setMaxRotation(45);

		this.fancyCoverFlow.setScaleDownGravity(0.2f);

		this.fancyCoverFlow.setActionDistance(FancyCoverFlow.ACTION_DISTANCE_AUTO);

		//homeList = new ArrayList<HomeScreen>();
		new JSONAsyncTask().execute("http://brinvents.com/jew/api/ListOfProducts/retrive.json?type=homeScreens");
	}

	protected void openAlert() {

		cDialog = new Dialog(HomeScreenImagesApi.this, android.R.style.Theme_Translucent);

		cDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

		cDialog.setCancelable(true);

		cDialog.setContentView(R.layout.dialog);

		TextView okTextView = (TextView) cDialog.findViewById(R.id.okText);

		okTextView.setOnClickListener(this);
		
		cDialog.show();
		/*AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(HomeScreenImagesApi.this);

		alertDialogBuilder.setTitle("Gold Price");

		alertDialogBuilder.setMessage("Selected gold price is");

		// set positive button: Yes message
		alertDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {

			public void onClick(DialogInterface dialog,int id) {
				// go to a new activity of the app
				Intent positveActivity = new Intent(getApplicationContext(), PositiveActivity.class);

				startActivity(positveActivity);
			}
		});

		AlertDialog alertDialog = alertDialogBuilder.create();
		// show alert
		alertDialog.show();*/
	}
	/**
	 * Helper method to start the animation on the splash screen
	 */
	private void AnimateandSlideShow() {

		slidingimage.setImageResource(IMAGE_IDS[currentimageindex % IMAGE_IDS.length]);

		currentimageindex++;

		Animation rotateimage = AnimationUtils.loadAnimation(this, R.anim.fade_in);

		slidingimage.startAnimation(rotateimage);
	}

	// DownloadJSON AsyncTask
	private class JSONAsyncTask extends AsyncTask<String, Void, ArrayList<String>>{

		ProgressDialog dialog;

		@Override
		protected void onPreExecute() {

			super.onPreExecute();

			dialog = new ProgressDialog(HomeScreenImagesApi.this);

			dialog.setMessage("LoadingImages, please Wait...");

			dialog.setTitle("connecting server..");

			dialog.show();

			dialog.setCancelable(false);
		}

		@Override
		protected ArrayList<String> doInBackground(String... urls) {

			try {
				HttpGet httpGet = new HttpGet(urls[0]);

				HttpClient httpclient = new DefaultHttpClient();

				HttpResponse response = httpclient.execute(httpGet);

				// StatusLine stat = response.getStatusLine();
				int status = response.getStatusLine().getStatusCode();

				if (status == 200) {

					HttpEntity entity = response.getEntity();

					String data = EntityUtils.toString(entity);

					JSONObject jsono = new JSONObject(data);

					System.out.println("response from the server-----------"+jsono);

					// Retrieve JSON Objects from the given website URL in JSONfunctions
					JSONObject result = jsono.getJSONObject("Result");

					// Retrieve JSON Objects
					// Storing each json item in variable
					int errorCode = result.getInt("errorCode");

					System.out.println("ERROR_CODE->"+errorCode);

					String errorMessage = result.getString("errorMessage");

					System.out.println("ERROR_MESSAGE->"+errorMessage);

					int statusCode = result.getInt("statusCode");

					System.out.println("STATUS_CODE->"+statusCode);

					// Locate the array name
					JSONArray jarray = result.getJSONArray("listOfItems");

					ArrayList<String> urlValues = new ArrayList<String>();

					for (int i = 0; i < jarray.length(); i++) 
					{
						jObj = jarray.getJSONObject(i);
						//imageView.setImageResource(R.drawable.ic_launcher);
						uri = jObj.getString("uri");

						System.out.println("uri----"+uri);

						urlValues.add(uri);
						//downloadImage(uri, "sample.png");
					}
					//new DownloadImageTask1(imageView).execute(uri);
					//new myAsyncTask().execute(uri);

					//getImageFromURL(uri);
					return urlValues;
				}
			} catch (ParseException e1) {

				e1.printStackTrace();

			} catch (IOException e) {

				e.printStackTrace();

			} catch (JSONException e) {

				e.printStackTrace();
			}
			return null;
		}

		protected void onPostExecute(ArrayList<String> urls) {

			dialog.cancel();
			//adapter.notifyDataSetChanged();
			/*if(result == false)
				Toast.makeText(mHomeScreen, "Unable to fetch data from server", Toast.LENGTH_LONG).show();*/
			if(urls != null) {

				mAdapter.setItems(urls);
			}
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {

		case R.id.CalculateId:

			openAlert();

			break;

		case R.id.okText:

			Intent positveActivity = new Intent(getApplicationContext(), PositiveActivity.class);

			startActivity(positveActivity);

		default:
			break;
		}

	}
}
