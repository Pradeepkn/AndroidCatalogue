package com.example.goldproject;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.Log;

public class FullScreenViewActivity extends Activity{
	
	private FullScreenImageAdapter adapter;
	
	private ViewPager viewPager;
	
	private ArrayList<Gold> fullImageList;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.single_click_image);
		
		viewPager = (ViewPager) findViewById(R.id.singlePager);
		
		// Get intent data
		Intent i = getIntent();
		
		// Selected image id
		int position = i.getExtras().getInt("id");
		
		Log.d("Position>>>", "Position" + position);
		
		adapter = new FullScreenImageAdapter(FullScreenViewActivity.this, fullImageList);

		viewPager.setAdapter(adapter);

		// displaying selected image first
		viewPager.setCurrentItem(position);
	}
}
