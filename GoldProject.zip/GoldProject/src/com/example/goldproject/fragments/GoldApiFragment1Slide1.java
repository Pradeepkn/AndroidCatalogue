package com.example.goldproject.fragments;

import com.example.goldproject.R;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.TextView;
import android.widget.ViewFlipper;

public class GoldApiFragment1Slide1 extends Fragment implements OnClickListener{

	private Activity mGoldApi;

	ViewFlipper flipper;

	private Animation inFromRightAnimation() {

		Animation inFromRight = new TranslateAnimation(

				Animation.RELATIVE_TO_PARENT,  +1.0f, Animation.RELATIVE_TO_PARENT,  0.0f,

				Animation.RELATIVE_TO_PARENT,  0.0f, Animation.RELATIVE_TO_PARENT,   0.0f
				);
		inFromRight.setDuration(500);

		inFromRight.setInterpolator(new AccelerateInterpolator());

		return inFromRight;
	}

	private Animation inFromLeftAnimation() {

		Animation inFromLeft = new TranslateAnimation(

				Animation.RELATIVE_TO_PARENT,  -1.0f, Animation.RELATIVE_TO_PARENT,  0.0f,

				Animation.RELATIVE_TO_PARENT,  0.0f, Animation.RELATIVE_TO_PARENT,   0.0f
				);
		inFromLeft.setDuration(500);

		inFromLeft.setInterpolator(new AccelerateInterpolator());

		return inFromLeft;
	}

	@Override
	public void onAttach(Activity activity) {

		mGoldApi = activity;

		super.onAttach(activity);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		System.out.println("gold API on create() started.......................");
		
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.gold_fragment_viewflipper, container, false);
		
		initSignUpComponenets(view);

		return view;
	}

	private void initSignUpComponenets(View view) {

		flipper = (ViewFlipper) view.findViewById(R.id.goldFlipper);

		TextView womenView= (TextView) view.findViewById(R.id.GoldWomenId);

		TextView mangalsuthraView = (TextView) view.findViewById(R.id.GoldMangangalaSutraId);

		womenView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				flipper.setInAnimation(inFromRightAnimation());

				flipper.showNext();
			}
		});

		mangalsuthraView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				flipper.setInAnimation(inFromRightAnimation());

				flipper.showNext();
			}
		});
	}

	@Override
	public void onClick(View v) {

	}
}
