package com.example.goldproject.fragments;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.goldproject.Gold;
import com.example.goldproject.GoldAdapter;
import com.example.goldproject.Platinum;
import com.example.goldproject.PlatinumAdapter;
import com.example.goldproject.R;
import com.tonicartos.widget.stickygridheaders.StickyGridHeadersGridView;
import com.tonicartos.widget.stickygridheaders.StickyGridHeadersGridView.OnHeaderClickListener;
import com.tonicartos.widget.stickygridheaders.StickyGridHeadersGridView.OnHeaderLongClickListener;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class PlatinumFragment2 extends Fragment implements OnClickListener, OnHeaderClickListener, OnHeaderLongClickListener, RadioGroup.OnCheckedChangeListener{

	ArrayList<Platinum> platinumList = new ArrayList<Platinum>();

	private PlatinumAdapter pAdapter;

	private GridView platinumGridView;

	private Activity mPlatinumApi2;

	public Context context;

	private Toast mToast;

	private Menu mMenu;

	private SegmentedRadioGroup segmentText;

	private SeekBar seekbar1; //Your SeekBar

	int value;        //The SeekBar value output

	private TextView result;  //The TextView which will display the result

	protected static final String TAG = "platinumApiFragment2";

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
	}

	@Override
	public void onAttach(Activity activity) {

		super.onAttach(activity);

		mPlatinumApi2 = activity;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.platinum_row1, container, false);

		return view;
	}
	@Override
	public void onHeaderClick(AdapterView<?> parent, View view, long id) {

		String text = "Header " + ((TextView)view.findViewById(R.id.SectionZero)).getText() + " clicked ";

		if (mToast == null) {

			mToast = Toast.makeText(getActivity(), text, Toast.LENGTH_SHORT);

		} else {

			mToast.setText(text);
		}
		mToast.show();
	}

	@Override
	public boolean onHeaderLongClick(AdapterView<?> parent, View view, long id) {

		String text = "Header " + ((TextView)view.findViewById(R.id.SectionZero)).getText() + " was long pressed!";

		if (mToast == null) {

			mToast = Toast.makeText(getActivity(), text, Toast.LENGTH_SHORT);

		} else {

			mToast.setText(text);
		}
		mToast.show();

		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {

		case R.id.menu_toggle_sticky:

			item.setChecked(!item.isChecked());

			((StickyGridHeadersGridView)platinumGridView).setAreHeadersSticky(!((StickyGridHeadersGridView)platinumGridView).areHeadersSticky());

			return true;

		case R.id.menu_use_list_adapter:

			platinumGridView.setAdapter(new ArrayAdapter<Platinum>(getActivity().getApplicationContext(), R.layout.platinum_row, platinumList));

			mMenu.findItem(R.id.menu_use_list_adapter).setVisible(false);

			mMenu.findItem(R.id.menu_use_sticky_adapter).setVisible(true);

			mMenu.findItem(R.id.menu_toggle_sticky).setVisible(false);

			return true;

		case R.id.menu_use_sticky_adapter:

			pAdapter = new PlatinumAdapter(mPlatinumApi2, R.layout.platinum_row, R.layout.header, platinumList);

			platinumGridView.setAdapter(pAdapter);

			mMenu.findItem(R.id.menu_use_list_adapter).setVisible(true);

			mMenu.findItem(R.id.menu_toggle_sticky).setVisible(true);

			mMenu.findItem(R.id.menu_use_sticky_adapter).setVisible(false);

			return true;

		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {

		super.onActivityCreated(savedInstanceState);

		seekbar1 = (SeekBar) getActivity().findViewById(R.id.platinumseekBar);

		result = (TextView) getActivity().findViewById(R.id.platinumPriceResult);

		//set change listener
		seekbar1.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

				value = progress;

				result.setText (" "+value);

				System.out.println("max value:"+value);
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {

			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {

			}
		});

		segmentText = (SegmentedRadioGroup) getActivity().findViewById(R.id.platinumsegment_text);

		segmentText.setOnCheckedChangeListener(this);

		mToast = Toast.makeText(mPlatinumApi2, " ", Toast.LENGTH_LONG);

		new JSONAsyncPlatinumTask().execute("http://brinvents.com/jew/api/ListOfProducts/retrive.json?type=Platinum");

		platinumGridView = (GridView) getActivity().findViewById(R.id.stickyGridHeadersPlatinumGridView1);

		pAdapter = new PlatinumAdapter(mPlatinumApi2, R.layout.header, R.layout.platinum_row, platinumList);

		platinumGridView.setAdapter(pAdapter);

		((StickyGridHeadersGridView)platinumGridView).setOnHeaderClickListener(this);

		((StickyGridHeadersGridView)platinumGridView).setOnHeaderLongClickListener(this);

		setHasOptionsMenu(true);

		platinumGridView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				Toast.makeText(mPlatinumApi2, platinumList.get(position).getUri(), Toast.LENGTH_LONG).show();	
			}
		});
	}

	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {

		if (group == segmentText) {

			if (checkedId == R.id.platinum_button_one) {

				mToast.setText("Price");

				mToast.show();
			} else if (checkedId == R.id.platinum_button_two) {

				mToast.setText("Purity");

				mToast.show();
			}  else if (checkedId == R.id.platinum_button_three) {

				mToast.setText("weight");

				mToast.show();
			} 
		}
	}

	class JSONAsyncPlatinumTask extends AsyncTask<String, Void, Boolean>{

		ProgressDialog dialog;

		@Override
		protected void onPreExecute() {

			super.onPreExecute();

			dialog = new ProgressDialog(mPlatinumApi2);

			dialog.setMessage("LoadingImages, please wait");

			dialog.setTitle("Connecting server");

			dialog.show();

			dialog.setCancelable(false);
		}

		@Override
		protected Boolean doInBackground(String... urls) {

			try {

				HttpGet httppost = new HttpGet(urls[0]);

				HttpClient httpclient = new DefaultHttpClient();

				HttpResponse response = httpclient.execute(httppost);

				int status = response.getStatusLine().getStatusCode();

				if (status == 200) {

					HttpEntity entity = response.getEntity();

					String data = EntityUtils.toString(entity);

					JSONObject json = new JSONObject(data);

					System.out.println("response from the server-----------"+json);

					JSONObject result = json.getJSONObject("Result");

					int errorCode = result.getInt("errorCode");

					System.out.println("ERROR_CODE->"+errorCode);

					String errorMessage = result.getString("errorMessage");

					System.out.println("ERROR_MESSAGE->"+errorMessage);

					int statusCode = result.getInt("statusCode");

					System.out.println("STATUS_CODE->"+statusCode);

					//jsonarray parse for listOfItems
					JSONArray jarray = result.getJSONArray("listOfItems");

					for (int i = 0; i < jarray.length(); i++) {

						JSONObject jsonObj = jarray.getJSONObject(i);

						//jsonarray parse for products
						JSONArray jarray1 = jsonObj.getJSONArray("products");

						for (int j = 0; j < jarray1.length(); j++) {

							JSONObject jsonObj1 = jarray1.getJSONObject(j);

							//jsonarray parse for items
							JSONArray jarray2 = jsonObj1.getJSONArray("items");

							for (int k = 0; k < jarray2.length(); k++) {

								JSONObject jsonObj2 = jarray2.getJSONObject(k);

								Platinum platinum = new Platinum();

								/*platinum.setCT(jsonObj.getString("CT"));
								platinum.setPT(jsonObj1.getString("PT"));
								platinum.setName(jsonObj2.getString("name"));
								platinum.setJewellery_type_name(jsonObj2.getString("jewellery_type_name"));
								platinum.setGender_name(jsonObj2.getString("gender_name"));
								platinum.setWearing_style_name(jsonObj2.getString("wearing_style_name"));
								platinum.setDesign_type_name(jsonObj2.getString("design_type_name"));
								platinum.setClarity_name(jsonObj2.getString("clarity_name"));
								platinum.setColor_name(jsonObj2.getString("color_name"));
								platinum.setRing_size_name(jsonObj2.getString("ring_size_name"));*/
								platinum.setUri(jsonObj2.getString("uri"));
								//platinum.setPrice(jsonObj2.getString("price"));

								platinumList.add(platinum);
							}
						}
					}
					return true;
				}
			} catch (ParseException e1) {

				e1.printStackTrace();

			} catch (IOException e) {

				e.printStackTrace();

			} catch (JSONException e) {

				e.printStackTrace();
			}
			return false;
		}

		protected void onPostExecute(Boolean result) {
			dialog.cancel();
			pAdapter.notifyDataSetChanged();
			if(result == false)
				Toast.makeText(mPlatinumApi2, "Unable to fetch data from server", Toast.LENGTH_LONG).show();
		}
	} 

	@Override
	public void onClick(View v) {

	}
}
