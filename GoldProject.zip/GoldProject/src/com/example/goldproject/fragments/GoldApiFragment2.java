package com.example.goldproject.fragments;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.example.goldproject.Gold;
import com.example.goldproject.GoldAdapter;
import com.example.goldproject.R;
import com.example.goldproject.SingleClickImage;
import com.tonicartos.widget.stickygridheaders.StickyGridHeadersGridView;
import com.tonicartos.widget.stickygridheaders.StickyGridHeadersGridView.OnHeaderClickListener;
import com.tonicartos.widget.stickygridheaders.StickyGridHeadersGridView.OnHeaderLongClickListener;

public class GoldApiFragment2 extends Fragment implements OnClickListener, OnHeaderClickListener, OnHeaderLongClickListener, RadioGroup.OnCheckedChangeListener {

	private ArrayList<Gold> goldList = new ArrayList<Gold>() ;

	private GoldAdapter gAdapter;

	private GridView gridView;

	public Activity mGoldApi2;

	public Context context;

	private Toast mToast;

	private Menu mMenu;

	//ViewFlipper flipper;

	//String sectionList[] = {"section=0", "section=1", "section=2", "section=3", "section=4", "section=5"};
	//SegmentedGroup segmented3;
	private SegmentedRadioGroup segmentText;
	//declare variables
	private SeekBar seekbar1; //Your SeekBar

	int value;        //The SeekBar value output

	private TextView result;  //The TextView which will display the result

	/*private static final String KEY_LIST_POSITION = "key_list_position";

	private static Callbacks sDummyCallbacks = new Callbacks() {
		@Override
		public void onItemSelected(int id) {
		}
	};

	private static final String STATE_ACTIVATED_POSITION = "activated_position";

	private int mActivatedPosition = ListView.INVALID_POSITION;

	private Callbacks mCallbacks = sDummyCallbacks;

	private int mFirstVisible;*/

	protected static final String TAG = "GoldApiFragment2";

	@Override
	public void onAttach(Activity activity) {

		super.onAttach(activity);

		mGoldApi2 = activity;

		/*// Activities containing this fragment must implement its callbacks.
		if (!(activity instanceof Callbacks)) {

			throw new IllegalStateException("Activity must implement fragment's callbacks.");
		}
		mCallbacks = (Callbacks)activity;*/
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

		inflater.inflate(R.menu.fragment_item_list, menu);

		mMenu = menu;

		menu.findItem(R.id.menu_toggle_sticky).setChecked(((StickyGridHeadersGridView)gridView).areHeadersSticky());
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.gold_row1, container, false);

		initLoginComponents(view);

		return view;
	}

	@Override
	public void onHeaderClick(AdapterView<?> parent, View view, long id) {

		String text = "Header " + ((TextView)view.findViewById(R.id.SectionZero)).getText() + " clicked ";

		if (mToast == null) {

			mToast = Toast.makeText(getActivity(), text, Toast.LENGTH_SHORT);

		} else {

			mToast.setText(text);
		}
		mToast.show();
	}

	@Override
	public boolean onHeaderLongClick(AdapterView<?> parent, View view, long id) {

		String text = "Header " + ((TextView)view.findViewById(R.id.SectionZero)).getText() + " was long pressed!";

		if (mToast == null) {

			mToast = Toast.makeText(getActivity(), text, Toast.LENGTH_SHORT);

		} else {

			mToast.setText(text);
		}
		mToast.show();

		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {

		case R.id.menu_toggle_sticky:

			item.setChecked(!item.isChecked());

			((StickyGridHeadersGridView)gridView).setAreHeadersSticky(!((StickyGridHeadersGridView)gridView).areHeadersSticky());

			return true;

		case R.id.menu_use_list_adapter:

			gridView.setAdapter(new ArrayAdapter<Gold>(getActivity().getApplicationContext(), R.layout.gold_row, goldList));

			mMenu.findItem(R.id.menu_use_list_adapter).setVisible(false);

			mMenu.findItem(R.id.menu_use_sticky_adapter).setVisible(true);

			mMenu.findItem(R.id.menu_toggle_sticky).setVisible(false);

			return true;

		case R.id.menu_use_sticky_adapter:

			gAdapter = new GoldAdapter(getActivity().getApplicationContext(), R.layout.gold_row, R.layout.header, goldList);

			gridView.setAdapter(gAdapter);

			mMenu.findItem(R.id.menu_use_list_adapter).setVisible(true);

			mMenu.findItem(R.id.menu_toggle_sticky).setVisible(true);

			mMenu.findItem(R.id.menu_use_sticky_adapter).setVisible(false);

			return true;

		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	/*@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		if (mActivatedPosition != ListView.INVALID_POSITION) {
			// Serialize and persist the activated item position.
			outState.putInt(STATE_ACTIVATED_POSITION, mActivatedPosition);
		}
	}*/

	private void initLoginComponents(View view) {

	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {

		super.onActivityCreated(savedInstanceState);

		/*// create RangeSeekBar as Integer range between 1000 and 500000
		RangeSeekBar<Integer> seekBar = new RangeSeekBar<Integer>(1000, 500000, mGoldApi2);

		seekBar.setOnRangeSeekBarChangeListener(new OnRangeSeekBarChangeListener<Integer>() {

			@Override
			public void onRangeSeekBarValuesChanged(RangeSeekBar<?> bar, Integer minValue, Integer maxValue) {
				// handle changed range values
				Log.i(TAG, "User selected new range values: MIN=" + minValue + ", MAX=" + maxValue);
			}
		});

		// add RangeSeekBar to pre-defined layout
		ViewGroup layout = (ViewGroup) mGoldApi2.findViewById(R.id.seekBarLinearLayout);

		layout.addView(seekBar);*/

		seekbar1 = (SeekBar) getActivity().findViewById(R.id.seekBar1);

		result = (TextView) getActivity().findViewById(R.id.goldPriceResult);

		//set change listener
		seekbar1.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

				value = progress;

				result.setText (" "+value);

				System.out.println("min value:"+value);
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {

			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {

			}
		});

		/*segmented3 = (SegmentedGroup) getActivity().findViewById(R.id.segmented3);
		//Tint color, and text color when checked
		segmented3.setTintColor(Color.parseColor("#FFD0FF3C"), Color.parseColor("#FF7B07B2"));

		segmented3.setOnCheckedChangeListener(this);*/
		segmentText = (SegmentedRadioGroup) getActivity().findViewById(R.id.segment_text);

		//Tint color, and text color when checked
		//segmentText.setTintColor(Color.parseColor("#FFD0FF3C"), Color.parseColor("#000000"));

		segmentText.setOnCheckedChangeListener(this);

		mToast = Toast.makeText(mGoldApi2, " ", Toast.LENGTH_LONG);

		new JSONAsyncGoldTask().execute("http://brinvents.com/jew/api/ListOfProducts/retrive.json?type=Gold");

		gridView = (GridView) getActivity().findViewById(R.id.stickyGridHeadersGridView1);

		//		gridView.setOnItemClickListener(this);

		gAdapter = new GoldAdapter(getActivity().getApplicationContext(), R.layout.header, R.layout.gold_row, goldList);

		gridView.setAdapter(gAdapter);

		/*if (savedInstanceState != null) {

			mFirstVisible = savedInstanceState.getInt(KEY_LIST_POSITION);
		}

		gridView.setSelection(mFirstVisible);

		// Restore the previously serialized activated item position.
		if (savedInstanceState != null && savedInstanceState.containsKey(STATE_ACTIVATED_POSITION)) {
			setActivatedPosition(savedInstanceState.getInt(STATE_ACTIVATED_POSITION));
		}*/

		//((StickyGridHeadersGridView) gridView).setAreHeadersSticky(false);

		((StickyGridHeadersGridView)gridView).setOnHeaderClickListener(this);

		((StickyGridHeadersGridView)gridView).setOnHeaderLongClickListener(this);

		setHasOptionsMenu(true);

		gridView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				//mCallbacks.onItemSelected(position);

				// Sending image id to FullScreenActivity
				Intent i = new Intent(getActivity().getApplicationContext(), SingleClickImage.class);

				//String index = goldList.get(position).getUri();

				//ArrayList<Gold> singleClick = (ArrayList<Gold>) gridView.getItemAtPosition(position);

				System.out.println("position..."+position);

				System.out.println("array index...."+goldList.get(position).getUri());

				String[] singleList = {goldList.get(position).getUri()};

				System.out.println("array image-----"+singleList);

				i.putExtra("id", singleList);
				/*for (int j = 0; j < index.length(); j++) {

					// passing array index
					i.putExtra("id", j);
				}*/
				startActivity(i);

				Toast.makeText(mGoldApi2, goldList.get(position).getUri(), Toast.LENGTH_LONG).show();	
			}
		});
	}


	/*@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {

		switch (checkedId) {
		case R.id.button31:
			Toast.makeText(getActivity(), "Price", Toast.LENGTH_SHORT).show();
			return;
		case R.id.button32:
			Toast.makeText(getActivity(), "Purity", Toast.LENGTH_SHORT).show();
			return;
		case R.id.button33:
			Toast.makeText(getActivity(), "Weight", Toast.LENGTH_SHORT).show();
			return;
		}
	}*/
	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {

		if (group == segmentText) {

			if (checkedId == R.id.gold_button_one) {

				mToast.setText("Price");

				mToast.show();
			} else if (checkedId == R.id.gold_button_two) {

				mToast.setText("Purity");

				mToast.show();
			}  else if (checkedId == R.id.gold_button_three) {

				mToast.setText("weight");

				mToast.show();
			} 
		}
	}

	/*@SuppressLint("NewApi")
	private void setActivatedPosition(int position) {
		if (position == ListView.INVALID_POSITION) {
			gridView.setItemChecked(mActivatedPosition, false);
		} else {
			gridView.setItemChecked(position, true);
		}

		mActivatedPosition = position;
	}

	 *//**
	 * A callback interface that all activities containing this fragment must
	 * implement. This mechanism allows activities to be notified of item
	 * selections.
	 *//*
	public interface Callbacks {
	  *//**
	  * Callback for when an item has been selected.
	  *//*
		public void onItemSelected(int position);
	}*/

	public class JSONAsyncGoldTask extends AsyncTask<String, Void, Boolean> {

		ProgressDialog dialog;

		@Override
		protected void onPreExecute() {

			super.onPreExecute();

			dialog = new ProgressDialog(mGoldApi2);

			dialog.setMessage("LoadingImages, please wait");

			dialog.setTitle("Connecting server");

			dialog.show();

			dialog.setCancelable(false);
		}

		@Override
		protected Boolean doInBackground(String... urls) {

			try {

				HttpGet httpGet = new HttpGet(urls[0]);

				HttpClient httpclient = new DefaultHttpClient();

				HttpResponse response = httpclient.execute(httpGet);

				int status = response.getStatusLine().getStatusCode();

				if (status == 200) {

					HttpEntity entity = response.getEntity();

					String data = EntityUtils.toString(entity);

					JSONObject json = new JSONObject(data);

					System.out.println("response from the server-----------"+json);

					JSONObject result = json.getJSONObject("Result");

					int errorCode = result.getInt("errorCode");

					System.out.println("ERROR_CODE->"+errorCode);

					String errorMessage = result.getString("errorMessage");

					System.out.println("ERROR_MESSAGE->"+errorMessage);

					int statusCode = result.getInt("statusCode");

					System.out.println("STATUS_CODE->"+statusCode);

					//jsonarray parse for listOfItems
					JSONArray jarray = result.getJSONArray("listOfItems");

					for (int i = 0; i < jarray.length(); i++) {

						JSONObject jsonObj = jarray.getJSONObject(i);

						//jsonarray parse for products
						JSONArray jarray1 = jsonObj.getJSONArray("products");

						for (int j = 0; j < jarray1.length(); j++) {

							JSONObject jsonObj1 = jarray1.getJSONObject(j);

							//jsonarray parse for items
							JSONArray jarray2 = jsonObj1.getJSONArray("items");

							for (int k = 0; k < jarray2.length(); k++) {

								JSONObject jsonObj2 = jarray2.getJSONObject(k);

								Gold gold = new Gold();

								/*	gold.setCT(jsonObj.getString("CT"));
								gold.setPT(jsonObj1.getString("PT"));
								gold.setName(jsonObj2.getString("name"));
								gold.setJewellery_type_name(jsonObj2.getString("jewellery_type_name"));
								gold.setGender_name(jsonObj2.getString("gender_name"));
								gold.setWearing_style_name(jsonObj2.getString("wearing_style_name"));
								gold.setDesign_type_name(jsonObj2.getString("design_type_name"));
								gold.setClarity_name(jsonObj2.getString("clarity_name"));
								gold.setColor_name(jsonObj2.getString("color_name"));
								gold.setRing_size_name(jsonObj2.getString("ring_size_name"));*/
								gold.setUri(jsonObj2.getString("uri"));
								//gold.setPrice(jsonObj2.getString("price"));

								goldList.add(gold);
							}
						}
					}
					return true;
				}
			} catch (ParseException e1) {

				e1.printStackTrace();

			} catch (IOException e) {

				e.printStackTrace();

			} catch (JSONException e) {

				e.printStackTrace();
			}
			return false;
		}

		protected void onPostExecute(Boolean result) {

			dialog.dismiss();

			gAdapter.notifyDataSetChanged();

			if(result == false)
				//shows a quick little msg for User
				Toast.makeText(mGoldApi2, "Unable to fetch data from server", Toast.LENGTH_LONG).show();
		}
	} 

	@Override
	public void onClick(View v) {

	}
}
