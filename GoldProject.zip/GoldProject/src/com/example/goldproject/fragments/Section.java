package com.example.goldproject.fragments;

public class Section {
	
	String sectionList[] = {"section=0","section=1", "section=2", "section=3", "section=4", "section=5", "section=6"};
}
