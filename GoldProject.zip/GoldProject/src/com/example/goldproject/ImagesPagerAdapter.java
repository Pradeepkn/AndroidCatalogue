package com.example.goldproject;

import android.support.v4.view.PagerAdapter;
import android.view.View;

public class ImagesPagerAdapter extends PagerAdapter {

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		// TODO Auto-generated method stub
		return false;
	}

}
