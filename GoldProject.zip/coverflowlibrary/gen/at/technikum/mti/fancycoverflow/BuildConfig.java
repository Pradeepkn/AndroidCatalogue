/** Automatically generated file. DO NOT MODIFY */
package at.technikum.mti.fancycoverflow;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}