package com.example.goldproject;

import java.io.File;
import java.util.ArrayList;

import com.example.goldproject.ViewWishListItems.ViewWishListAdapter.ViewWishListHolder;
import com.example.goldproject.jewellerymodels.GoldItems;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class ViewWishListItems extends ActionBarActivity {

	String goldViewWishListImgFileName;

	ArrayList<GoldItems> goldViewWishListItems;

	ViewWishListAdapter wishListAdapter;

	private ViewWishListAdapter viewWishListAdapter;

	ViewWishListHolder holder;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		getSupportActionBar().hide();

		setContentView(R.layout.viewwishlistlayout);

		Intent intent = getIntent();

		goldViewWishListImgFileName = intent.getStringExtra("viewWishListImgFilename");

		System.out.println("viewWishListinclick img pos--" +goldViewWishListImgFileName);

		goldViewWishListItems = (ArrayList<GoldItems>) intent.getSerializableExtra("viewWishListItems");

		goldViewWishListItems = new ArrayList<GoldItems>();

		ListView wishListView = (ListView) findViewById(R.id.viewWishListView);

		viewWishListAdapter = new ViewWishListAdapter(ViewWishListItems.this, R.layout.view_wishlist_items_row, goldViewWishListItems, goldViewWishListImgFileName);

		viewWishListAdapter.setItems(goldViewWishListItems);

		wishListView.setAdapter(viewWishListAdapter);
	}

	public class ViewWishListAdapter extends ArrayAdapter<GoldItems> {

		private ArrayList<GoldItems> mGoldItem = new ArrayList<GoldItems>();

		private LayoutInflater layoutInflater;

		private Activity gActivity;

		int Resource;

		String imageWishList;

		public void setItems(ArrayList<GoldItems> item) {

			mGoldItem.clear();

			if (item != null) {

				mGoldItem.addAll(item);
			}
			notifyDataSetChanged();
		}
		public ViewWishListAdapter(Activity activity, int resource, ArrayList<GoldItems> wishListItems, String image) {

			super(activity, resource, wishListItems);

			layoutInflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

			this.gActivity = activity;

			Resource = resource;

			mGoldItem = wishListItems;

			imageWishList = image;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			View v = convertView;

			if (v == null) {

				holder = new ViewWishListHolder();

				v = layoutInflater.inflate(Resource, null);

				holder.viewWishListImage = (ImageView) convertView.findViewById(R.id.goldItemsWishListImg);

				holder.itemName = (TextView) convertView.findViewById(R.id.itemNameWishList);

				holder.item_price = (TextView) convertView.findViewById(R.id.item_priceWishList);

				holder.item_purity = (TextView) convertView.findViewById(R.id.item_purityWishList);

				v.setTag(holder);
			}
			else {
				holder = (ViewWishListHolder) v.getTag();
			}

			System.out.println("url filename--" +goldViewWishListImgFileName);

			File SDCardRoot = Environment.getExternalStorageDirectory().getAbsoluteFile();

			if (goldViewWishListImgFileName != null && !goldViewWishListImgFileName.isEmpty()) {

				File imgFile = new File(SDCardRoot, goldViewWishListImgFileName);

				System.out.println("imgFile---" + imgFile);

				System.out.println("fullImageListUrl---" + goldViewWishListImgFileName);

				if (imgFile.exists()) {

					Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());

					holder.viewWishListImage.setImageBitmap(myBitmap);

					holder.itemName.setText("ItemName: " +mGoldItem.get(position).name);

					holder.item_price.setText("Price: " + mGoldItem.get(position).price);

					holder.item_purity.setText("Purity " +mGoldItem.get(position).purity);
				}
			}
			return v;
		}
		public class ViewWishListHolder {

			private TextView itemName, item_price, item_purity;

			private ImageView viewWishListImage;
		}
	}
}
