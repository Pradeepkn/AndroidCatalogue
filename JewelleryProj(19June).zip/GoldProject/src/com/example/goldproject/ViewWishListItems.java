package com.example.goldproject;

import java.io.File;
import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class ViewWishListItems extends ActionBarActivity {

	String goldViewWishListImgFileName;

	ArrayList<String> goldViewWishListItems;

	public ViewWishListAdapter viewWishListAdapter;

	TextView wishlistUserName;

	ListView wishListView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		System.out.println("entering to wishlist activity.....");

		super.onCreate(savedInstanceState);

		this.setContentView(R.layout.viewwishlistlayout);

		getSupportActionBar().hide();

		Intent intent = getIntent();

		String wishListUserName = intent.getStringExtra("collUserName");

		System.out.println("userName----" +wishListUserName);

		goldViewWishListImgFileName = intent.getStringExtra("viewWishListImgFilename");

		System.out.println("viewWishListinclick img pos--" +goldViewWishListImgFileName);

		goldViewWishListItems = new ArrayList<String>();

		//goldViewWishListItems = (ArrayList<String>) intent.getStringArrayListExtra("viewWishListItems");

		goldViewWishListItems = (ArrayList<String>) intent.getExtras().getStringArrayList("viewWishListItems");

		System.out.println("goldViewWishListItems---" +goldViewWishListItems);

		wishlistUserName = (TextView) findViewById(R.id.userWishList);

		wishlistUserName.setText(wishListUserName + "\t" + "Wish List");

		wishListView = (ListView) findViewById(R.id.viewWishListView);

		viewWishListAdapter = new ViewWishListAdapter(this, R.layout.view_wishlist_items_row, goldViewWishListItems, goldViewWishListImgFileName);

		//		viewWishListAdapter.setItems(goldViewWishListItems);

		wishListView.setAdapter(viewWishListAdapter);
		
		viewWishListAdapter.notifyDataSetChanged();

		/*wishListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {
				AlertDialog.Builder adb=new AlertDialog.Builder(ViewWishListItems.this);
				adb.setTitle("Delete?");
				adb.setMessage("Are you sure you want to delete " + position);
				final int positionToRemove = position;
				adb.setNegativeButton("Cancel", null);
				adb.setPositiveButton("Ok", new AlertDialog.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
//						MyDataObject.remove(positionToRemove);
						viewWishListAdapter.notifyDataSetChanged();
					}});
				adb.show();
			}
		});*/
	}

	//A concrete BaseAdapter that is backed by an array of arbitrary objects. 
	public class ViewWishListAdapter extends ArrayAdapter<String> {

		private ViewWishListAdapter mViewWishListAdapter;

		private ArrayList<String> mGoldItem;

		private LayoutInflater layoutInflater;

		private Activity gActivity;

		int Resource;

		String imageWishList;

		ViewWishListHolder holder;

		/*public void setItems(ArrayList<GoldItems> item) {

			mGoldItem.clear();

			if (item != null) {

				mGoldItem.addAll(item);
			}
			notifyDataSetChanged();
		}*/
		public ViewWishListAdapter(Activity mActivity, int resource, ArrayList<String> imgFileListItems, String imageFileName) {

			super(mActivity, resource, imgFileListItems);

			layoutInflater = (LayoutInflater) mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

			gActivity = mActivity;

			Resource = resource;

			imageWishList = imageFileName;

			mGoldItem = imgFileListItems;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			View v = convertView;

			if (v == null) {

				holder = new ViewWishListHolder();

				v = layoutInflater.inflate(Resource, null);

				v.setTag(holder);
			}
			else {
				holder = (ViewWishListHolder) v.getTag();
			}
			
			Button removeItemsButton = (Button) v.findViewById(R.id.removeButtonId);
			
			removeItemsButton.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					
					int pos = (int)v.getTag();
	                  goldViewWishListItems.remove(pos);
	                  viewWishListAdapter.notifyDataSetChanged();  
				}
			});
			
			System.out.println("url filename--" +goldViewWishListImgFileName);

			//to get path of sdcard 
			File SDCardRoot = Environment.getExternalStorageDirectory().getAbsoluteFile();

			if (goldViewWishListImgFileName != null && !goldViewWishListImgFileName.isEmpty()) {

				File imgFile = new File(SDCardRoot, goldViewWishListImgFileName);

				System.out.println("imgFile---" + imgFile);

				System.out.println("fullImageListUrl---" + goldViewWishListImgFileName);

				if (imgFile.exists()) {

					holder.viewWishListImage = (ImageView) v.findViewById(R.id.goldItemsWishListImg);

					//					holder.viewWishListImage.setAlpha(127);

					holder.itemName = (TextView) v.findViewById(R.id.itemNameWishList);

					holder.item_price = (TextView) v.findViewById(R.id.item_priceWishList);

					holder.item_purity = (TextView) v.findViewById(R.id.item_purityWishList);

					Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());

					holder.viewWishListImage.setImageResource(R.drawable.ic_launcher);

					holder.viewWishListImage.setImageBitmap(myBitmap);

					System.out.println("goldViewWishListItems------" +goldViewWishListItems);

					System.out.println("goldViewWishListItems.size()---" +goldViewWishListItems.size());

					holder.itemName.setText("ItemName: " +goldViewWishListItems.get(0));

					holder.item_price.setText("Price: " +goldViewWishListItems.get(1));

					holder.item_purity.setText("Purity: " +goldViewWishListItems.get(2));
				}
			}
			return v;
		}
		public class ViewWishListHolder {

			private TextView itemName, item_price, item_purity;

			private ImageView viewWishListImage;

			/*public ViewWishListHolder(){

				super();

				this.viewWishListImage = viewWishListImage;

				this.itemName = itemName;

				this.item_price = item_price;

				this.item_purity = item_purity;
			}*/
		}
	}
}
