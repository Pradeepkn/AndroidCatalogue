package com.example.goldproject.fragments;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.example.goldproject.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.ExpandableListView.OnGroupCollapseListener;
import android.widget.ExpandableListView.OnGroupExpandListener;

public class GoldApiFirstFragment extends Fragment {

	ExpandableListAdapter listAdapter;
	ExpandableListView expListView;
	List<String> listDataHeader;
	HashMap<String, List<String>> listDataChild;

	private Activity mGoldApi;

	/*private ArrayList<GoldItems> goldItemsCategory;

	private Context context;

	//get list of goldproduct types
	private ArrayList<GoldProducts> fFragGoldProducts = new ArrayList<GoldProducts>();

	//	private String url = "http://brinvents.com/jewellery/api/ListOfProducts/retrive.json?type=Gold";

	private ViewFlipper goldFlipper;

	private TextView womenTextViewRow;

	private TextView menTextViewRow;

	//	private ImageView womenItemsLeftFlip;

	//	private ImageView menItemsLeftFlip;

	private Animation inFromRightAnimation() {

		Animation inFromRight = new TranslateAnimation(

				Animation.RELATIVE_TO_PARENT,  +1.0f, Animation.RELATIVE_TO_PARENT,  0.0f,

				Animation.RELATIVE_TO_PARENT,  0.0f, Animation.RELATIVE_TO_PARENT,   0.0f
				);
		inFromRight.setDuration(500);

		inFromRight.setInterpolator(new AccelerateInterpolator());

		return inFromRight;
	}

	private Animation inFromLeftAnimation() {

		Animation inFromLeft = new TranslateAnimation(

				Animation.RELATIVE_TO_PARENT,  -1.0f, Animation.RELATIVE_TO_PARENT,  0.0f,

				Animation.RELATIVE_TO_PARENT,  0.0f, Animation.RELATIVE_TO_PARENT,   0.0f
				);
		inFromLeft.setDuration(500);

		inFromLeft.setInterpolator(new AccelerateInterpolator());

		return inFromLeft;
	}*/

	@Override
	public void onAttach(Activity activity) {

		mGoldApi = activity;

		super.onAttach(activity);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		System.out.println("gold API on create() started.......................");
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.expandable_list_main, container, false);

		// get the listview
		expListView = (ExpandableListView) view.findViewById(R.id.lvExp);

		// preparing list data
		prepareListData();

		listAdapter = new ExpandableListAdapter(getActivity(), listDataHeader, listDataChild);

		// setting list adapter
		expListView.setAdapter(listAdapter);

		/*View view = inflater.inflate(R.layout.gold_fragment_viewflipper, container, false);*/

		/*initSignUpComponenets(view);*/

		expListView.setOnGroupClickListener(new OnGroupClickListener() {

			@Override
			public boolean onGroupClick(ExpandableListView parent, View v,
					int groupPosition, long id) {
				// Toast.makeText(getApplicationContext(),
				// "Group Clicked " + listDataHeader.get(groupPosition),
				// Toast.LENGTH_SHORT).show();
				return false;
			}
		});

		// Listview Group expanded listener
		expListView.setOnGroupExpandListener(new OnGroupExpandListener() {

			@Override
			public void onGroupExpand(int groupPosition) {
				/*Toast.makeText(getApplicationContext(),
	 	                   listDataHeader.get(groupPosition) + " Expanded",
	 	                   Toast.LENGTH_SHORT).show();*/
			}
		});

		// Listview Group collasped listener
		expListView.setOnGroupCollapseListener(new OnGroupCollapseListener() {

			@Override
			public void onGroupCollapse(int groupPosition) {
				/*Toast.makeText(getApplicationContext(),
	 	                   listDataHeader.get(groupPosition) + " Collapsed",
	 	                   Toast.LENGTH_SHORT).show();*/

			}
		});

		// Listview on child click listener
		expListView.setOnChildClickListener(new OnChildClickListener() {

			@Override
			public boolean onChildClick(ExpandableListView parent, View v,
					int groupPosition, int childPosition, long id) {

				if(listDataHeader.get(groupPosition) == "Men")
				{
					if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Ring") {

						Intent in0 = new Intent("men-gold-items");

						in0.putExtra("Men Ring-category", "Ring");

						LocalBroadcastManager mgr0 = LocalBroadcastManager.getInstance(getActivity());

						mgr0.sendBroadcast(in0);
					}
					else if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Bracelet") {

						Intent in1 = new Intent("men-gold-items");

						in1.putExtra("Men Bracelet-category", "Bracelet");

						LocalBroadcastManager mgr1 = LocalBroadcastManager.getInstance(getActivity());

						mgr1.sendBroadcast(in1);
					}
					else if(listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Chain") {

						Intent in2 = new Intent("men-gold-items");

						in2.putExtra("Men Chain-category", "Chain");

						LocalBroadcastManager mgr2 = LocalBroadcastManager.getInstance(getActivity());

						mgr2.sendBroadcast(in2);
					}
				}
				else if (listDataHeader.get(groupPosition) == "Women") {

					if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Bangles") {

						Intent in0 = new Intent("women-gold-items");

						in0.putExtra("Bangles-category", "Bangles");

						LocalBroadcastManager mgr0 = LocalBroadcastManager.getInstance(getActivity());

						mgr0.sendBroadcast(in0);
					}
					else if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Ear Ring") {

						Intent in1 = new Intent("women-gold-items");

						in1.putExtra("Ear Ring-category", "Ear Ring");

						LocalBroadcastManager mgr1 = LocalBroadcastManager.getInstance(getActivity());

						mgr1.sendBroadcast(in1);

					}
					else if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Necklace") {
						
						Intent in2 = new Intent("women-gold-items");

						in2.putExtra("Necklace-category", "Necklace");

						LocalBroadcastManager mgr2 = LocalBroadcastManager.getInstance(getActivity());

						mgr2.sendBroadcast(in2);
					}
					else if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Black Beeds chain") {

						Intent in3 = new Intent("women-gold-items");

						in3.putExtra("Black Beeds Chain-category", "Black Beeds Chain");

						LocalBroadcastManager mgr3 = LocalBroadcastManager.getInstance(getActivity());

						mgr3.sendBroadcast(in3);
					}
					else if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Tanmania") {

						Intent in4 = new Intent("women-gold-items");

						in4.putExtra("Tanmania-category", "Tanmania");

						LocalBroadcastManager mgr4 = LocalBroadcastManager.getInstance(getActivity());

						mgr4.sendBroadcast(in4);
					}
					else if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Ring") {

						Intent in5 = new Intent("women-gold-items");

						in5.putExtra("Ring-category", "Ring");

						LocalBroadcastManager mgr5 = LocalBroadcastManager.getInstance(getActivity());

						mgr5.sendBroadcast(in5);
					}
					else if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Pendant") {

						Intent in6 = new Intent("women-gold-items");

						in6.putExtra("Pendant-category", "Pendant");

						LocalBroadcastManager mgr6 = LocalBroadcastManager.getInstance(getActivity());

						mgr6.sendBroadcast(in6);
					}
					else if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Chain") {

						Intent in7 = new Intent("women-gold-items");

						in7.putExtra("Chain-category", "Chain");

						LocalBroadcastManager mgr7 = LocalBroadcastManager.getInstance(getActivity());

						mgr7.sendBroadcast(in7);
					}

					else if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Mangalsutra") {

						Intent in8 = new Intent("women-gold-items");

						in8.putExtra("Mangalsutra-category", "Mangalasutra");

						LocalBroadcastManager mgr8 = LocalBroadcastManager.getInstance(getActivity());

						mgr8.sendBroadcast(in8);
					}

					else if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Necklace Set") {

						Intent in9 = new Intent("women-gold-items");

						in9.putExtra("Necklace Set-category", "Neckalce Set");

						LocalBroadcastManager mgr9 = LocalBroadcastManager.getInstance(getActivity());

						mgr9.sendBroadcast(in9);
					}

					else if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Bracelet") {

						Intent in10 = new Intent("women-gold-items");

						in10.putExtra("Bracelet Set-category", "Bracelet");

						LocalBroadcastManager mgr10 = LocalBroadcastManager.getInstance(getActivity());

						mgr10.sendBroadcast(in10);
					}

					else if (listDataChild.get(listDataHeader.get(groupPosition)).get(childPosition) == "Mang Tikka") {

						Intent in11 = new Intent("women-gold-items");

						in11.putExtra("Mang Tikka-category", "Maang Tikka");

						LocalBroadcastManager mgr11 = LocalBroadcastManager.getInstance(getActivity());

						mgr11.sendBroadcast(in11);
					}	 	    												
				}
				return false;
			}
		});
		return view;
	}

	private void prepareListData() {
		listDataHeader = new ArrayList<String>();
		listDataChild = new HashMap<String, List<String>>();

		// Adding child data
		listDataHeader.add("Men");
		listDataHeader.add("Women");
		/*listDataHeader.add("kids");*/

		// Adding child data
		List<String> men = new ArrayList<String>();
		men.add("Ring");
		men.add("Chain");
		men.add("Bracelet");

		List<String> women = new ArrayList<String>();
		women.add("Bangles");
		women.add("Ear Ring");
		women.add("Necklace");
		women.add("Black beeds chain");
		women.add("Tanmania");
		women.add("Ring");
		women.add("Pendant");
		women.add("Chain");
		women.add("Mangalsutra");
		women.add("Necklace Set");
		women.add("Bracelet");
		women.add("Mang Tikka");

		// Header, Child data
		listDataChild.put(listDataHeader.get(0), men);
		listDataChild.put(listDataHeader.get(1), women);
	}

	// Listview Group click listener

	/*private void initSignUpComponenets(View view) {

		goldFlipper = (ViewFlipper) view.findViewById(R.id.goldViewFlipperFrag1);

		womenTextViewRow = (TextView) view.findViewById(R.id.GoldWomenItemsId);

		menTextViewRow = (TextView) view.findViewById(R.id.GoldMenId);

		//		womenItemsLeftFlip = (ImageView) view.findViewById(R.id.womenItemsLeftFlip);

		//		menItemsLeftFlip = (ImageView) view.findViewById(R.id.menItemsLeftFlip);

		womenTextViewRow.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				// Send an Intent with an action named "my-event". 
				Intent intent = new Intent("womenItems");

				intent.putExtra("womenFirstFrag", "Women");

				//Helper to register for and send broadcasts of Intents to local objects within your process.
				LocalBroadcastManager mgr = LocalBroadcastManager.getInstance(getActivity());

				mgr.sendBroadcast(intent);
			}
		});*/

	/*womenItemsLeftFlip.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				goldFlipper.setInAnimation(inFromRightAnimation());

				goldFlipper.showNext();
			}
		});*/

	/*menItemsLeftFlip.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				goldFlipper.setInAnimation(inFromRightAnimation());

				goldFlipper.showNext();
			}
		});*/

	/*		menTextViewRow.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				// Send an Intent with an action named "my-event". 
				Intent intent = new Intent("menItems");

				intent.putExtra("menFirstFrag", "Men");

				//Helper to register for and send broadcasts of Intents to local objects within your process.
				LocalBroadcastManager mgr = LocalBroadcastManager.getInstance(getActivity());

				mgr.sendBroadcast(intent);
			}
		});


	@Override
	public void onActivityCreated(Bundle savedInstanceState) {

		super.onActivityCreated(savedInstanceState);

		// preparing list data
		//		prepareListData();

		//		listAdapter = new ExpandableListAdapter(getActivity().getApplicationContext(), listDataHeader, listDataChild);

		// setting list adapter
		//		expListView.setAdapter(listAdapter);

		// Listview Group click listener
		expListView.setOnGroupClickListener(new OnGroupClickListener() {

			@Override
			public boolean onGroupClick(ExpandableListView parent, View v,
					int groupPosition, long id) {
				// Toast.makeText(getApplicationContext(),
				// "Group Clicked " + listDataHeader.get(groupPosition),
				// Toast.LENGTH_SHORT).show();
				return false;
			}
		});

		// Listview Group expanded listener
		expListView.setOnGroupExpandListener(new OnGroupExpandListener() {

			@Override
			public void onGroupExpand(int groupPosition) {
			}
		});

		// Listview Group collasped listener
		expListView.setOnGroupCollapseListener(new OnGroupCollapseListener() {

			@Override
			public void onGroupCollapse(int groupPosition) {
			}
		});

		// Listview on child click listener
		expListView.setOnChildClickListener(new OnChildClickListener() {

			@Override
			public boolean onChildClick(ExpandableListView parent, View v,
					int groupPosition, int childPosition, long id) {

				if (groupPosition == 0) {

					Intent intent = new Intent("my-event");

					intent.putExtra("menGoldItems0", "Ring");

					LocalBroadcastManager mgr = LocalBroadcastManager.getInstance(getActivity());

					mgr.sendBroadcast(intent);

				} else if (groupPosition == 1) {

					Intent intent = new Intent("my-event");

					intent.putExtra("menGoldItems1", "Chain");

					LocalBroadcastManager mgr = LocalBroadcastManager.getInstance(getActivity());

					mgr.sendBroadcast(intent);

				} else if (groupPosition == 2) {

					Intent intent = new Intent();

					intent.putExtra("menGoldItems2", "Bracelet");

					LocalBroadcastManager mgr = LocalBroadcastManager.getInstance(getActivity());

					mgr.sendBroadcast(intent);
				}
				return false;
			}
		});

		ArrayList<GoldProducts> gProducts = new ArrayList<GoldProducts>();

		for (int i = 0; i < fFragGoldProducts.size(); i++) {

			System.out.println("firstfrag goldproducts size--" +fFragGoldProducts.size());

			GoldProducts gProducts1 = fFragGoldProducts.get(i);

			ArrayList<GoldItems> gItems = gProducts1.items;

			if (gItems == null) {

				continue;
			}
			ArrayList<GoldItems> gItemsList = new ArrayList<GoldItems>();

			for (int j = 0; j < gItems.size(); j++) {

				System.out.println("gItems size--" +gItems.size());

				GoldItems gItems1 = gItems.get(j);

				String genderName = gItems1.getGender();

				System.out.println("gold each Items name--" +genderName);

				if (genderName.equals("Women") || genderName.equals("Men") || genderName.equals("Kids") || genderName.equals("Occasions")) {

					womenTextViewRow.setText(genderName);
					//map every goldItems in list
					gItemsList.add(gItems1);
				}else {
					//					menTextViewRow.setText(genderName);
				}
			}
			System.out.println("final gItemsList---" +gItemsList.size());

			if (gItemsList.size() > 0) {

				gProducts1.items = gItemsList;

				//map each goldProducts items in to a list
				gProducts.add(gProducts1);
			}
		}
		updateItemsView(gProducts);

		// Call Async task to get the gold items
		//		new JsonGoldItemsTask().execute();
	}

	public class JsonGoldItemsTask extends AsyncTask <Void, Void, ArrayList<GoldProducts>> {

		@Override
		protected void onPreExecute() {

			super.onPreExecute();
		}

		@Override
		protected ArrayList<GoldProducts> doInBackground(Void... args) {

			System.out.println("background process strated");

			ServiceHandler serviceClient = new ServiceHandler();

			String jsonResp = serviceClient.makeServiceCall(url, ServiceHandler.GET);

			System.out.println("response from url--" + jsonResp);

			if(jsonResp != null){

				try {
					JSONObject json = new JSONObject(jsonResp);

					System.out.println("response from the server-----------"+json);

					JSONObject result = json.getJSONObject("Result");

					int errorCode = result.getInt("errorCode");

					System.out.println("ERROR_CODE->"+errorCode);

					String errorMessage = result.getString("errorMessage");

					System.out.println("ERROR_MESSAGE->"+errorMessage);

					int statusCode = result.getInt("statusCode");

					System.out.println("STATUS_CODE->"+statusCode);

					//jsonarray parse for listOfItems
					JSONArray jarray = result.getJSONArray("listOfItems");

					// create an array list for Gold product array
					ArrayList<GoldProducts> productList = new ArrayList<GoldProducts>();

					for (int i = 0; i < jarray.length(); i++) {

						JSONObject jsonObj = jarray.getJSONObject(i);

						//jsonarray parse for products
						JSONArray jarray1 = jsonObj.getJSONArray("products");

						for (int j = 0; j < jarray1.length(); j++) {

							JSONObject products  = jarray1.optJSONObject(j);

							if (products == null) {

								continue;
							}
							//jsonarray parse for items
							JSONArray itemJsonArray  = products.getJSONArray("items");

							goldItemsCategory = new ArrayList<GoldItems>();

							for (int k = 0; k < itemJsonArray.length(); k++) {

								final JSONObject itemObject = itemJsonArray.optJSONObject(k);

								if (itemObject == null) {

									continue;
								}
								GoldItems gItems = new GoldItems();

								gItems.gender = itemObject.optString("gender_name");

								goldItemsCategory.add(gItems);

								String productName = products.optString("PT");

								if ((TextUtils.isEmpty(productName) != true) && (goldItemsCategory.size() > 0)) {

									GoldProducts product = new GoldProducts();

									product.productName = productName;

									product.items = goldItemsCategory;

									productList.add(product);
								}
							}
						}
						return productList;
					}
				}catch (JSONException e) {

					e.printStackTrace();
				} 
			}else {
				Log.e("JSON data", "didn't receive the response from JSON url");
			}
			return null;
		}

		@Override
		protected void onPostExecute(ArrayList<GoldProducts> result) {

			super.onPostExecute(result);

			if (result == null) {

				return;
			}
		}
	}
	private void updateItemsView(ArrayList<GoldProducts> result) {

		ArrayList<GoldItems> items = new ArrayList<GoldItems>();

		for (int i = 0; i < result.size(); i++) {

			System.out.println("GoldProducts size--" + result.size());

			GoldProducts product = result.get(i);

			items = product.items;

			for (int j = 0; j < items.size(); j++) {

				GoldItems gItems2 = items.get(j);

				String genderName = gItems2.getGender();

				if (genderName.equals("Women")) {

					womenTextViewRow.setText(genderName);
				} else {
					//					menTextViewRow.setText(genderName);
				}
			}
		}
	}*/
}
