package com.example.goldproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.widget.TextView;

public class PlatinumApi extends ActionBarActivity {

	TextView platinumApiUserName;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_platinum_api);

		System.out.println("entering to platinum API");
		
		platinumApiUserName = (TextView) findViewById(R.id.platinumUserName);

		Intent intent = getIntent();

		String userName = intent.getStringExtra("userName");

		platinumApiUserName.setText(userName);

		getSupportActionBar().hide();
	}
}
