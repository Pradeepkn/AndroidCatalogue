package com.example.goldproject;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class FeedbackAPI extends Activity {

	EditText smileAddImage, emailID;

	ImageView smileImage, sadImage, smileBigImage, neutralImage, smilingHappy, smileMorehappy;

	TextView addImageIcon;

	Button sendImageIconButton;

	EditText userNameFeedback, userFeedbackRating, userFeedbackText;

	int TAG_ERRORCODE;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_feedback_api);

		//		smileAddImage = (EditText) findViewById(R.id.smileImageAdd);

		smileImage = (ImageView) findViewById(R.id.imageSmiling);

		sadImage = (ImageView) findViewById(R.id.imageSad);

		smileBigImage = (ImageView) findViewById(R.id.imageSmilingBig);

		neutralImage = (ImageView) findViewById(R.id.imageSmilingNeutral);	

		smilingHappy = (ImageView) findViewById(R.id.imageSmilingHappy);

		smileMorehappy = (ImageView) findViewById(R.id.imageSmilingMoreHappy);

		addImageIcon = (TextView) findViewById(R.id.addImageIcon);

		sendImageIconButton = (Button) findViewById(R.id.sendImageIcon);

		userNameFeedback = (EditText) findViewById(R.id.userNameEditText);

		userFeedbackRating = (EditText) findViewById(R.id.counting_rateApp);

		userFeedbackText = (EditText) findViewById(R.id.userFeedbackEditText);

		emailID = (EditText) findViewById(R.id.emailIdEditText);

		userFeedbackText.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				addImage(smileImage.getDrawable());
			}
		});
		smileImage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				addImage(smileImage.getDrawable());
			}
		});
		smileBigImage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				//Return the view's drawable, or null if no drawable has been assigned.
				addImage(smileBigImage.getDrawable());
			}
		});
		sadImage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				addImage(sadImage.getDrawable());
			}
		});
		neutralImage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				addImage(neutralImage.getDrawable());
			}
		});

		smilingHappy.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				addImage(smilingHappy.getDrawable());
			}
		});

		smileMorehappy.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				addImage(smileMorehappy.getDrawable());
			}
		});

		sendImageIconButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				final String Name = userNameFeedback.getText().toString();

				final String Counting_rate = userFeedbackRating.getText().toString();

				final String Text = userFeedbackText.getText().toString();

				final String emailid = emailID.getText().toString();

				if (Name.equals("") || Counting_rate.equals("") || Text.equals("") || emailid.equals("")) {

					if (Name.equals("")) {

						Toast.makeText(FeedbackAPI.this, "username should not be empty..", Toast.LENGTH_LONG).show();
					} else if (Counting_rate.equals("")) {

						Toast.makeText(FeedbackAPI.this, "userfeedbackratings should not be empty..", Toast.LENGTH_LONG).show();
					} else if (Text.equals("")) {

						Toast.makeText(FeedbackAPI.this, "userfeedback should not be empty..", Toast.LENGTH_LONG).show();
					}else if (emailid.equals("")) {

						Toast.makeText(FeedbackAPI.this, "emailId should not be empty", Toast.LENGTH_LONG).show();
					}
				} else {

					new UserFeedback().execute("http://brinvents.com/jewellery/api/feedback.php");
				}
				//				addImageIcon.setText(smileAddImage.getText());
			}
		});
	}

	public class UserFeedback extends AsyncTask<String, String, String> {

		public ProgressDialog fDialog;

		String companyEmaiId;

		String Name;

		String Counting_rate;

		String Text;

		@Override
		protected void onPreExecute() {

			super.onPreExecute();

			fDialog = new ProgressDialog(FeedbackAPI.this);

			fDialog.setMessage("Your feedback sending to mail...");

			fDialog.setCancelable(false);

			fDialog.show();
		}

		@Override
		protected String doInBackground(String... urls) {

			String responseText = null;

			Name = userNameFeedback.getText().toString();

			Counting_rate = userFeedbackRating.getText().toString();

			Text = userFeedbackText.getText().toString();

			companyEmaiId = emailID.getText().toString();

			System.out.println("emailID---" +companyEmaiId);

			System.out.println("userName--" +Name);

			System.out.println("userRate--" +Counting_rate);

			System.out.println("userFeedback--" +Text);

			try {
				JSONObject jObj = new JSONObject();

				jObj.put("Name", Name);

				jObj.put("Counting_rate", Counting_rate);

				jObj.put("Text", Text);

				System.out.println("json object--" +jObj);

				HttpPost httpPostReq = new HttpPost(urls[0]);

				HttpClient httpClient = new DefaultHttpClient();

				StringEntity se = new StringEntity(jObj.toString());

				System.out.println("string entity---" +se);

				se.setContentType("application/json;charset=UTF-8");

				se.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE,"application/json;charset=UTF-8"));

				httpPostReq.setEntity(se);

				HttpResponse httpResponse = httpClient.execute(httpPostReq);

				try {
					responseText = EntityUtils.toString(httpResponse.getEntity());

					System.out.println("json response----" +responseText);

				}catch (ParseException e) {

					e.printStackTrace();

					Log.i("Parse Exception", e + "response got");

				} catch (IOException e) {

					e.printStackTrace();
				}

				JSONObject jsonObj = new JSONObject(responseText);

				System.out.println("response from json---" +jsonObj);

				JSONObject result = jsonObj.getJSONObject("Result");

				TAG_ERRORCODE = result.getInt("errorCode");

				System.out.println("errorCode -->" +TAG_ERRORCODE);

				String errorMessage = result.getString("errorMessage");

				System.out.println("errorMessage -->" +errorMessage);

				String statusCode = result.getString("statusCode");

				System.out.println("sttusCode -->" +statusCode);

			} catch (JSONException e) {

				e.printStackTrace();

			} catch (ClientProtocolException e1) {

				e1.printStackTrace();

			} catch (IOException e1) {

				e1.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(String result) {

			fDialog.dismiss();

			if (TAG_ERRORCODE == 0) {

				Intent Email = new Intent(Intent.ACTION_SEND);

				Email.putExtra(Intent.EXTRA_EMAIL, new String[]{companyEmaiId});

				Email.putExtra(Intent.EXTRA_SUBJECT, Name);

				Email.putExtra(Intent.EXTRA_TEXT, Text);

				Email.putExtra(Intent.EXTRA_TEXT, Counting_rate);

				//need this to prompts email client only
				Email.setType("message/rfc822");

				// the user can choose the email client
				startActivity(Intent.createChooser(Email, "Choose an email client from..."));
				//finish();

				Toast.makeText(FeedbackAPI.this, "Your Feedback sent to mail", Toast.LENGTH_LONG).show();
			} else {
				Toast.makeText(FeedbackAPI.this, "Failed to send your feedback", Toast.LENGTH_LONG).show();
			}
		}
	}

	private void addImage(Drawable drawable) {

		drawable .setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());

		int selectionCursor = userFeedbackText.getSelectionStart();
		userFeedbackText.getText().insert(selectionCursor, ".");
		selectionCursor = userFeedbackText.getSelectionStart();

		SpannableStringBuilder builder = new SpannableStringBuilder(userFeedbackText.getText());
		builder.setSpan(new ImageSpan(drawable), selectionCursor - ".".length(), selectionCursor, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		userFeedbackText.setText(builder);
		userFeedbackText.setSelection(selectionCursor);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.feedback_api, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
